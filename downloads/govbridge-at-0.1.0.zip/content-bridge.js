"use strict";
(() => {
  // config/extension-targets.json
  var extension_targets_default = {
    productionOrigin: "https://www.meinesv.at",
    demoOrigin: "https://govbridge-at-demo.manuel857067.chatgpt.site",
    developmentOrigins: [
      "http://localhost:4173",
      "http://127.0.0.1:4173"
    ]
  };

  // src/environment/site-context.ts
  var SITE_ENVIRONMENTS = ["production", "demo", "development"];
  var EXTENSION_TARGETS = Object.freeze({
    productionOrigin: extension_targets_default.productionOrigin,
    demoOrigin: extension_targets_default.demoOrigin,
    developmentOrigins: Object.freeze([...extension_targets_default.developmentOrigins])
  });
  var PRODUCTION_ORIGIN = EXTENSION_TARGETS.productionOrigin;
  var DEMO_ORIGIN = EXTENSION_TARGETS.demoOrigin ?? void 0;
  var DEVELOPMENT_ORIGINS = EXTENSION_TARGETS.developmentOrigins;
  function configuredBuildProfile() {
    return ["extension", ...SITE_ENVIRONMENTS].includes("extension") ? "extension" : "extension";
  }
  var BUILD_PROFILE = configuredBuildProfile();
  function exactOrigin(rawOrigin) {
    try {
      const parsed = new URL(rawOrigin);
      if (parsed.origin !== rawOrigin || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) return void 0;
      return parsed.origin;
    } catch {
      return void 0;
    }
  }
  function isLoopbackDevelopmentOrigin(origin) {
    try {
      const parsed = new URL(origin);
      return parsed.protocol === "http:" && (parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1") && parsed.port === "4173" && exactOrigin(origin) !== void 0;
    } catch {
      return false;
    }
  }
  function originContexts() {
    const contexts = [];
    const production = exactOrigin(PRODUCTION_ORIGIN);
    if (production) contexts.push({ origin: production, environment: "production" });
    const demo = DEMO_ORIGIN && exactOrigin(DEMO_ORIGIN);
    if (demo && demo !== production && demo.startsWith("https://")) {
      contexts.push({ origin: demo, environment: "demo" });
    }
    for (const origin of DEVELOPMENT_ORIGINS) {
      if (isLoopbackDevelopmentOrigin(origin) && !contexts.some((context) => context.origin === origin)) {
        contexts.push({ origin, environment: "development" });
      }
    }
    return contexts;
  }
  function profileAllowsEnvironment(profile, environment) {
    return ["extension", ...SITE_ENVIRONMENTS].includes(profile) && SITE_ENVIRONMENTS.includes(environment);
  }
  function resolveSiteContext(rawUrl, profile = BUILD_PROFILE) {
    if (!rawUrl) return void 0;
    try {
      const url = new URL(rawUrl);
      const origin = url.origin;
      const context = originContexts().find((candidate) => candidate.origin === origin);
      return context && profileAllowsEnvironment(profile, context.environment) ? context : void 0;
    } catch {
      return void 0;
    }
  }

  // src/webmcp/catalog.ts
  var EMPTY_INPUT_SCHEMA = Object.freeze({
    type: "object",
    properties: Object.freeze({}),
    additionalProperties: false
  });
  var CLAIM_ID_INPUT_SCHEMA = Object.freeze({
    type: "object",
    required: Object.freeze(["claimId"]),
    properties: Object.freeze({
      claimId: Object.freeze({ type: "string", minLength: 1, maxLength: 256 })
    }),
    additionalProperties: false
  });
  var CLAIM_TOOL_CATALOG = Object.freeze([
    Object.freeze({
      name: "list_claims",
      description: "Read OEGK claims rendered on the current page now, in page order. No refresh or stored history. Results include current-page completeness; IDs are temporary.",
      inputSchema: EMPTY_INPUT_SCHEMA
    }),
    Object.freeze({
      name: "get_open_claims",
      description: "Read the current OEGK page and return claims whose status is submitted or processing. Current-page scope only.",
      inputSchema: EMPTY_INPUT_SCHEMA
    }),
    Object.freeze({
      name: "get_claim",
      description: "Read the current OEGK page and find a temporary snapshot claim ID. Never navigates. If NOT_FOUND, list again.",
      inputSchema: CLAIM_ID_INPUT_SCHEMA
    })
  ]);
  var SEARCH_PAGE_PATH = "/vsInfo/views/KE/einreichungTyp.xhtml";
  var SEARCH_ENTRY_PATH = "/vsInfo/views/KE/";
  var SEARCH_RESULTS_PATH = "/vsInfo/views/KE/einreichungListe.xhtml";
  var SEARCH_CONTENT_ID = "10007.815943";
  var SEARCH_TOOL = Object.freeze({
    name: "search_claims",
    description: "Request a Wahlarzt / Wahltherapeut search on MeineSV for inclusive ISO dates, at most five calendar years. Registered on query and results routes; execution requires the validated query form or retained results-range form. Submits the current form once; does not return claims or confirm success. Navigation may return null or destroy execution. Never automatically retry an uncertain submission; cancellation cannot undo a dispatched click.",
    inputSchema: Object.freeze({
      type: "object",
      required: Object.freeze(["from", "to"]),
      properties: Object.freeze({
        from: Object.freeze({ type: "string", format: "date", pattern: "^[0-9]{4}-[0-9]{2}-[0-9]{2}$" }),
        to: Object.freeze({ type: "string", format: "date", pattern: "^[0-9]{4}-[0-9]{2}-[0-9]{2}$" })
      }),
      additionalProperties: false
    })
  });
  var PAGE_TOOL_CATALOG = Object.freeze([...CLAIM_TOOL_CATALOG, SEARCH_TOOL]);
  function isSearchPageUrl(rawUrl, profile) {
    try {
      const url = new URL(rawUrl ?? "");
      return resolveSiteContext(url, profile) !== void 0 && (url.pathname === SEARCH_PAGE_PATH || url.pathname === SEARCH_ENTRY_PATH && url.searchParams.get("contentid") === SEARCH_CONTENT_ID);
    } catch {
      return false;
    }
  }
  function isSearchResultsUrl(rawUrl, profile) {
    try {
      const url = new URL(rawUrl ?? "");
      return resolveSiteContext(url, profile) !== void 0 && url.pathname === SEARCH_RESULTS_PATH;
    } catch {
      return false;
    }
  }
  function isSearchToolUrl(rawUrl, profile) {
    return isSearchPageUrl(rawUrl, profile) || isSearchResultsUrl(rawUrl, profile);
  }
  function isPageToolName(value) {
    return value === "search_claims" || isClaimToolName(value);
  }
  function daysInMonth(year, month) {
    if (month === 2) return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28;
    return [4, 6, 9, 11].includes(month) ? 30 : 31;
  }
  function calendarDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    return year >= 1 && month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth(year, month);
  }
  function isValidSearchInput(input) {
    if (!isExactObject(input, ["from", "to"]) || !calendarDate(input.from) || !calendarDate(input.to)) return false;
    const [year, month, day] = input.from.split("-").map(Number);
    const lastDay = Math.min(day, daysInMonth(year + 5, month));
    const [toYear, toMonth, toDay] = input.to.split("-").map(Number);
    return input.from <= input.to && toYear * 1e4 + toMonth * 100 + toDay <= (year + 5) * 1e4 + month * 100 + lastDay;
  }
  function isValidPageToolInput(tool, input) {
    return tool === "search_claims" ? isValidSearchInput(input) : isValidClaimToolInput(tool, input);
  }
  var CLAIM_TOOL_NAMES = new Set(CLAIM_TOOL_CATALOG.map(({ name }) => name));
  function isClaimToolName(value) {
    return typeof value === "string" && CLAIM_TOOL_NAMES.has(value);
  }
  function isExactObject(input, keys) {
    if (input === null || typeof input !== "object" || Array.isArray(input)) return false;
    const prototype = Object.getPrototypeOf(input);
    if (prototype !== Object.prototype && prototype !== null) return false;
    const actual = Object.keys(input);
    return actual.length === keys.length && keys.every((key) => actual.includes(key));
  }
  function isValidClaimToolInput(tool, input) {
    if (tool === "list_claims" || tool === "get_open_claims") return isExactObject(input, []);
    if (tool === "get_claim") {
      return isExactObject(input, ["claimId"]) && typeof input.claimId === "string" && input.claimId.length >= 1 && input.claimId.length <= 256;
    }
    return false;
  }

  // src/webmcp/protocol.ts
  var WEBMCP_BRIDGE_PROTOCOL = "oegk-claim-tracker.webmcp";
  var WEBMCP_BRIDGE_VERSION = 1;
  var MAX_REQUEST_ID_LENGTH = 128;
  var MAX_FRAME_LENGTH = 5e6;
  function record(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }
  function onlyKeys(value, keys) {
    const actual = Object.keys(value);
    return actual.length === keys.length && keys.every((key) => actual.includes(key));
  }
  function validRequestId(value) {
    return typeof value === "string" && value.length >= 1 && value.length <= MAX_REQUEST_ID_LENGTH;
  }
  function jsonCompatible(value, depth = 0) {
    if (depth > 24) return false;
    if (value === null || typeof value === "string" || typeof value === "boolean") return true;
    if (typeof value === "number") return Number.isFinite(value);
    if (Array.isArray(value)) return value.every((item) => jsonCompatible(item, depth + 1));
    if (!record(value)) return false;
    return Object.entries(value).every(([key, item]) => key !== "__proto__" && jsonCompatible(item, depth + 1));
  }
  function withinFrameLimit(value) {
    try {
      return JSON.stringify(value).length <= MAX_FRAME_LENGTH;
    } catch {
      return false;
    }
  }
  function isToolResult(value) {
    if (!record(value) || typeof value.ok !== "boolean") return false;
    if (value.ok) {
      return onlyKeys(value, ["ok", "data"]) && jsonCompatible(value.data) && withinFrameLimit(value);
    }
    if (!onlyKeys(value, ["ok", "error"]) || !record(value.error) || !onlyKeys(value.error, ["code", "message"])) return false;
    return (/* @__PURE__ */ new Set(["INVALID_INPUT", "NOT_FOUND", "PAGE_NOT_READY", "EXTRACTION_FAILED", "INTERNAL_ERROR", "UNSUPPORTED_PAGE", "FORM_UNAVAILABLE", "SEARCH_IN_PROGRESS"])).has(
      String(value.error.code)
    ) && typeof value.error.message === "string" && value.error.message.length <= 256 && withinFrameLimit(value);
  }
  function parseBridgeRequest(value) {
    if (!record(value) || !onlyKeys(value, ["protocol", "version", "direction", "requestId", "tool", "input"])) {
      return void 0;
    }
    if (value.protocol !== WEBMCP_BRIDGE_PROTOCOL || value.version !== WEBMCP_BRIDGE_VERSION || value.direction !== "request" || !validRequestId(value.requestId) || !isPageToolName(value.tool) || !isValidPageToolInput(value.tool, value.input) || !withinFrameLimit(value)) return void 0;
    return value;
  }
  function createBridgeResponse(requestId, result) {
    return {
      protocol: WEBMCP_BRIDGE_PROTOCOL,
      version: WEBMCP_BRIDGE_VERSION,
      direction: "response",
      requestId,
      result
    };
  }

  // src/webmcp/content-bridge.ts
  var INTERNAL_FAILURE = Object.freeze({
    ok: false,
    error: Object.freeze({ code: "INTERNAL_ERROR", message: "Tool execution failed." })
  });
  function installContentBridge(pageWindow, invoke) {
    const inFlight = /* @__PURE__ */ new Set();
    let disposed = false;
    const onMessage = (event) => {
      if (disposed || event.source !== pageWindow || event.origin !== pageWindow.location.origin) return;
      const request = parseBridgeRequest(event.data);
      if (!request || inFlight.has(request.requestId)) return;
      inFlight.add(request.requestId);
      void invoke(request.tool, request.input).then((result) => {
        const safeResult = isToolResult(result) ? result : INTERNAL_FAILURE;
        if (!disposed) {
          pageWindow.postMessage(
            createBridgeResponse(request.requestId, safeResult),
            pageWindow.location.origin
          );
        }
      }).catch(() => {
        if (!disposed) {
          pageWindow.postMessage(
            createBridgeResponse(request.requestId, INTERNAL_FAILURE),
            pageWindow.location.origin
          );
        }
      }).finally(() => inFlight.delete(request.requestId));
    };
    pageWindow.addEventListener("message", onMessage);
    return () => {
      disposed = true;
      inFlight.clear();
      pageWindow.removeEventListener("message", onMessage);
    };
  }

  // src/webmcp/runtime.ts
  function disposeOnFinalPageHide(pageWindow, dispose) {
    const onPageHide = (event) => {
      if (event.persisted) return;
      pageWindow.removeEventListener("pagehide", onPageHide);
      dispose();
    };
    pageWindow.addEventListener("pagehide", onPageHide);
    return () => pageWindow.removeEventListener("pagehide", onPageHide);
  }

  // src/webmcp/scope.ts
  var SUPPORTED_PATHS = /* @__PURE__ */ new Set([
    "/vsInfo/views/KE/einreichungTyp.xhtml",
    "/vsInfo/views/KE/einreichungListe.xhtml",
    "/vsInfo/views/KE/einreichungDetailOA.xhtml",
    "/vsInfo/views/KE/einreichungDetail.xhtml"
  ]);
  function isSupportedMeineSvUrl(rawUrl, profile) {
    if (!rawUrl) return false;
    try {
      const url = new URL(rawUrl);
      return resolveSiteContext(url, profile) !== void 0 && (SUPPORTED_PATHS.has(url.pathname) || isSearchPageUrl(url.toString(), profile));
    } catch {
      return false;
    }
  }

  // src/webmcp/diagnostics.ts
  function writeAttribute(name, value) {
    const root = document.documentElement;
    if (!root) return false;
    root.setAttribute(name, value);
    return true;
  }
  function publishBridgeStatus(name, value) {
    if (writeAttribute(name, value)) return;
    document.addEventListener("DOMContentLoaded", () => writeAttribute(name, value), { once: true });
  }

  // src/environment/demo-labels.ts
  var GERMAN_LABELS = Object.freeze({
    typeHeading: "Einreichungen abfragen",
    resultsHeading: "Liste der Einreichungen",
    detailHeading: "Einreichung Detail",
    doctorTab: "Wahlarzt / Wahltherapeut",
    continueSubmit: "Weiter",
    resultsSubmit: "OK",
    openClaims: "offene Einreichungen",
    rejectedClaims: "abgelehnte Einreichungen",
    reimbursedClaims: "erstattete Einreichungen",
    invoiceDated: "Rechnung vom",
    reimbursement: "R\xFCckerstattung:",
    provider: "Behandler:",
    invoiceAmount: "Rechnungsbetrag:",
    claimReference: "Antragsnummer:",
    treatmentFrom: "Behandlung ab:",
    treatmentPeriod: "Behandlungszeitraum:",
    reimbursementAmount: "H\xF6he der Kostenerstattung:",
    reimbursementDate: "Datum der Erstattung:",
    reasonForRejection: "Ablehnungsgrund:",
    empty: "In diesem Abfragezeitraum wurde keine Kostenerstattung bzw. kein Onlineantrag gefunden.",
    invalidEntries: "Fehlerhafte Eingaben im Formular",
    rangeError: "Der Abfragezeitraum darf h\xF6chstens 5 Jahre betragen.",
    datePlaceholder: "TT.MM.JJJJ"
  });
  var ENGLISH_LABELS = Object.freeze({
    typeHeading: "Search claims",
    resultsHeading: "Claims",
    detailHeading: "Claim details",
    doctorTab: "Private doctor / therapist",
    continueSubmit: "Continue",
    resultsSubmit: "OK",
    openClaims: "Open claims",
    rejectedClaims: "Rejected claims",
    reimbursedClaims: "Reimbursed claims",
    invoiceDated: "Invoice dated",
    reimbursement: "Reimbursement:",
    provider: "Provider:",
    invoiceAmount: "Invoice amount:",
    claimReference: "Claim reference:",
    treatmentFrom: "Treatment from:",
    treatmentPeriod: "Treatment period:",
    reimbursementAmount: "Reimbursement amount:",
    reimbursementDate: "Reimbursement date:",
    reasonForRejection: "Reason for rejection:",
    empty: "No reimbursement or online claim was found for this date range.",
    invalidEntries: "Invalid form entries",
    rangeError: "The date range must not exceed 5 years.",
    datePlaceholder: "DD.MM.YYYY"
  });
  function labelsForOrigin(origin, expectedOrigin, documentLanguage) {
    if (origin !== expectedOrigin && expectedOrigin !== void 0) return GERMAN_LABELS;
    const context = resolveSiteContext(origin);
    return context && context.origin === origin && context.environment !== "production" && documentLanguage?.trim().toLowerCase() === "en" ? ENGLISH_LABELS : GERMAN_LABELS;
  }

  // src/actions/search-claims.ts
  var busyDocuments = /* @__PURE__ */ new WeakSet();
  var dispatchedDocuments = /* @__PURE__ */ new WeakSet();
  var pendingDocuments = /* @__PURE__ */ new WeakMap();
  function labelsForPage(page) {
    try {
      const context = resolveSiteContext(page.URL);
      return context ? labelsForOrigin(context.origin, context.origin, page.documentElement?.lang) : GERMAN_LABELS;
    } catch {
      return GERMAN_LABELS;
    }
  }
  function outcomeNodes(page) {
    const labels = labelsForPage(page);
    const results = Array.from(page.querySelectorAll('.card_container [role="grid"], .card_container [role="row"]'));
    const alerts = Array.from(page.querySelectorAll('[role="alert"]')).filter((alert) => [labels.empty, labels.invalidEntries, labels.rangeError].some((message) => text(alert).includes(message)));
    return [...results, ...alerts];
  }
  function isSearchPending(page) {
    if (busyDocuments.has(page)) return true;
    const previous = pendingDocuments.get(page);
    if (!previous) return false;
    const current = outcomeNodes(page);
    if (current.some((node) => !previous.has(node))) {
      pendingDocuments.delete(page);
      return false;
    }
    return true;
  }
  function failure(code) {
    const messages = {
      INVALID_INPUT: "Invalid search dates.",
      UNSUPPORTED_PAGE: "Search is unavailable on this page.",
      FORM_UNAVAILABLE: "The active search form is unavailable or ambiguous.",
      SEARCH_IN_PROGRESS: "A search has already been requested in this document. Do not retry automatically.",
      INTERNAL_ERROR: "Search execution failed. Submission may be uncertain; do not retry automatically."
    };
    return { ok: false, error: { code, message: messages[code] ?? "Search execution failed." } };
  }
  function text(element) {
    return (element.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function visible(element) {
    const view = element.ownerDocument.defaultView;
    if (!view || !element.isConnected || element.getClientRects().length === 0) return false;
    for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
      if (ancestor.hidden || ancestor.hasAttribute("inert") || ancestor.getAttribute("aria-hidden") === "true") return false;
      const style = view.getComputedStyle(ancestor);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
    }
    return true;
  }
  function enabled(element) {
    return !element.matches(":disabled") && !element.closest('[aria-disabled="true"]');
  }
  function activeTab(tab) {
    return visible(tab) && enabled(tab) && tab.getAttribute("aria-selected") === "true";
  }
  function safeDestination(form, submitter, pageUrl, expectedPath, expectedOrigin) {
    const method = submitter.getAttribute("formmethod") ?? form.getAttribute("method") ?? "get";
    if (method.trim().toLowerCase() !== "post") return false;
    const actions = [form.getAttribute("action"), submitter.getAttribute("formaction")];
    try {
      for (const action of actions) {
        if (action === null) continue;
        const url = new URL(action || pageUrl, form.ownerDocument.baseURI);
        if (url.origin !== expectedOrigin || url.pathname !== expectedPath || url.username || url.password || url.hash) return false;
      }
      if (form.getAttribute("method")?.trim().toLowerCase() !== "post") return false;
      const baseTarget = form.ownerDocument.querySelector("base[target]")?.getAttribute("target") ?? "";
      const formTarget = form.getAttribute("target") || baseTarget;
      const effectiveTarget = submitter.getAttribute("formtarget") ?? formTarget;
      return [formTarget, effectiveTarget].every((target) => target === "" || target.toLowerCase() === "_self");
    } catch {
      return false;
    }
  }
  function inspectForm(pageDocument) {
    const context = resolveSiteContext(pageDocument.URL);
    if (!context) return void 0;
    const labels = labelsForOrigin(context.origin, context.origin, pageDocument.documentElement?.lang);
    const typeRoute = isSearchPageUrl(pageDocument.URL) && new URL(pageDocument.URL).pathname === SEARCH_PAGE_PATH;
    const resultsRoute = isSearchResultsUrl(pageDocument.URL);
    if (!typeRoute && !resultsRoute) return void 0;
    const expectedHeading = typeRoute ? labels.typeHeading : labels.resultsHeading;
    const headings = Array.from(pageDocument.querySelectorAll("h1")).filter((heading) => visible(heading) && text(heading) === expectedHeading);
    if (headings.length !== 1) return void 0;
    const fromName = typeRoute ? "vonDatWAH" : "vonDat";
    const toName = typeRoute ? "bisDatWAH" : "bisDat";
    const fromInputs = pageDocument.querySelectorAll(`[id="${fromName}"], input[name="${fromName}"]`);
    const toInputs = pageDocument.querySelectorAll(`[id="${toName}"], input[name="${toName}"]`);
    if (fromInputs.length !== 1 || toInputs.length !== 1) return void 0;
    const from = fromInputs[0];
    const to = toInputs[0];
    if (![from, to].every((input) => input instanceof HTMLInputElement && input.type === "text" && input.id === input.name && !input.readOnly && visible(input) && enabled(input))) return void 0;
    const form = from.form;
    if (!form || to.form !== form || !visible(form)) return void 0;
    if (typeRoute) {
      const tabs = Array.from(form.querySelectorAll('[role="tab"]')).filter((tab) => text(tab) === labels.doctorTab);
      if (tabs.length !== 1 || !activeTab(tabs[0])) return void 0;
      if (Array.from(form.querySelectorAll('[role="tab"]')).some((tab) => tab !== tabs[0] && activeTab(tab))) return void 0;
    }
    const expectedSubmitterText = typeRoute ? labels.continueSubmit : labels.resultsSubmit;
    const submitters = Array.from(pageDocument.querySelectorAll(
      'input[type="submit" i], button[type="submit" i], button:not([type])'
    )).filter((control) => control.form === form && (control instanceof HTMLInputElement ? control.value.trim() === expectedSubmitterText : text(control) === expectedSubmitterText) && visible(control) && enabled(control));
    const expectedPath = typeRoute ? SEARCH_PAGE_PATH : SEARCH_RESULTS_PATH;
    if (submitters.length !== 1 || !safeDestination(form, submitters[0], pageDocument.URL, expectedPath, context.origin)) return void 0;
    return { form, from, to, submitter: submitters[0] };
  }
  function sameForm(left, right) {
    return !!right && left.form === right.form && left.from === right.from && left.to === right.to && left.submitter === right.submitter;
  }
  function displayDate(iso) {
    const [year, month, day] = iso.split("-");
    return `${day}.${month}.${year}`;
  }
  async function searchClaims(pageDocument, input) {
    if (!isValidSearchInput(input)) return failure("INVALID_INPUT");
    if (!isSearchToolUrl(pageDocument.URL)) {
      return failure("UNSUPPORTED_PAGE");
    }
    if (busyDocuments.has(pageDocument) || dispatchedDocuments.has(pageDocument)) return failure("SEARCH_IN_PROGRESS");
    busyDocuments.add(pageDocument);
    try {
      const controls = inspectForm(pageDocument);
      if (!controls) return failure("FORM_UNAVAILABLE");
      const setValue = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      if (!setValue) return failure("FORM_UNAVAILABLE");
      const from = displayDate(input.from);
      const to = displayDate(input.to);
      for (const [control, value] of [[controls.from, from], [controls.to, to]]) {
        if (!sameForm(controls, inspectForm(pageDocument))) return failure("FORM_UNAVAILABLE");
        setValue.call(control, value);
        control.dispatchEvent(new Event("input", { bubbles: true }));
        control.dispatchEvent(new Event("change", { bubbles: true }));
      }
      if (!sameForm(controls, inspectForm(pageDocument)) || controls.from.value !== from || controls.to.value !== to) {
        return failure("FORM_UNAVAILABLE");
      }
      pendingDocuments.set(pageDocument, new WeakSet(outcomeNodes(pageDocument)));
      dispatchedDocuments.add(pageDocument);
      controls.submitter.click();
      return { ok: true, data: { status: "submission_requested" } };
    } catch {
      return failure("INTERNAL_ERROR");
    } finally {
      busyDocuments.delete(pageDocument);
    }
  }

  // src/domain/claim.ts
  var CLAIM_STATUSES = [
    "submitted",
    "processing",
    "completed",
    "rejected",
    "unknown"
  ];
  var CLAIM_KEYS = /* @__PURE__ */ new Set([
    "id",
    "provider",
    "treatmentDate",
    "treatmentEndDate",
    "invoiceDate",
    "submittedDate",
    "reimbursementDate",
    "invoiceAmount",
    "reimbursementAmount",
    "status",
    "responseAvailable",
    "source",
    "lastSeen"
  ]);
  var DATE_KEYS = [
    "treatmentDate",
    "treatmentEndDate",
    "invoiceDate",
    "submittedDate",
    "reimbursementDate"
  ];
  var AMOUNT_KEYS = ["invoiceAmount", "reimbursementAmount"];
  function normalizeText(value) {
    if (typeof value !== "string") return void 0;
    const normalized = value.trim().replace(/\s+/gu, " ");
    return normalized || void 0;
  }
  function normalizeLocalDate(value) {
    if (typeof value !== "string") return void 0;
    const text2 = value.trim();
    let year;
    let month;
    let day;
    let match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text2);
    if (match) {
      year = Number(match[1]);
      month = Number(match[2]);
      day = Number(match[3]);
    } else {
      match = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(text2);
      if (!match) return void 0;
      day = Number(match[1]);
      month = Number(match[2]);
      year = Number(match[3]);
    }
    const utc = new Date(Date.UTC(year, month - 1, day));
    if (utc.getUTCFullYear() !== year || utc.getUTCMonth() !== month - 1 || utc.getUTCDate() !== day) {
      return void 0;
    }
    return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }
  function normalizeEuroAmount(value) {
    if (typeof value === "number") {
      return Number.isFinite(value) && value >= 0 ? Math.round(value * 100) / 100 : void 0;
    }
    if (typeof value !== "string") return void 0;
    let text2 = value.trim();
    if (!text2 || /(?:USD|GBP|CHF|\$|£)/iu.test(text2)) return void 0;
    text2 = text2.replace(/(?:EUR|€)/giu, "").replace(/[\u00a0\u202f ]/gu, "").trim();
    if (!text2 || text2.startsWith("-") || /[^\d.,+]/u.test(text2) || text2.includes("+")) return void 0;
    const comma = text2.lastIndexOf(",");
    const dot = text2.lastIndexOf(".");
    let decimalSep;
    if (comma >= 0 && dot >= 0) {
      if (dot > comma) return void 0;
      decimalSep = ",";
    } else if (comma >= 0) {
      const digits = text2.length - comma - 1;
      if (digits <= 2) decimalSep = ",";
    } else if (dot >= 0) {
      const digits = text2.length - dot - 1;
      if (digits <= 2) decimalSep = ".";
    }
    const groupingSep = decimalSep === "," ? "." : decimalSep === "." ? "," : void 0;
    const pieces = decimalSep ? text2.split(decimalSep) : [text2];
    if (pieces.length > 2) return void 0;
    const integerPart = pieces[0];
    const fraction = pieces[1];
    if (!integerPart || fraction !== void 0 && !/^\d{1,2}$/u.test(fraction)) return void 0;
    let integerDigits = integerPart;
    if (groupingSep && integerPart.includes(groupingSep)) {
      const groups = integerPart.split(groupingSep);
      if (!/^\d{1,3}$/u.test(groups[0] ?? "") || groups.slice(1).some((group) => !/^\d{3}$/u.test(group))) return void 0;
      integerDigits = groups.join("");
    } else if (!decimalSep && /[.,]/u.test(integerPart)) {
      const sep = integerPart.includes(".") ? "." : ",";
      const groups = integerPart.split(sep);
      if (!/^\d{1,3}$/u.test(groups[0] ?? "") || groups.slice(1).some((group) => !/^\d{3}$/u.test(group))) return void 0;
      integerDigits = groups.join("");
    }
    if (!/^\d+$/u.test(integerDigits)) return void 0;
    const result = Number(`${integerDigits}.${fraction ?? "0"}`);
    return Number.isFinite(result) ? Math.round(result * 100) / 100 : void 0;
  }
  function validInstant(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/u.test(value)) return false;
    const parsed = new Date(value);
    const canonical = value.includes(".") ? value : value.replace(/Z$/u, ".000Z");
    return Number.isFinite(parsed.valueOf()) && parsed.toISOString() === canonical;
  }
  function isClaim(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record2 = value;
    if (Object.keys(record2).some((key) => !CLAIM_KEYS.has(key))) return false;
    if (typeof record2.id !== "string" || !record2.id || record2.source !== "oegk" || !CLAIM_STATUSES.includes(record2.status) || !validInstant(record2.lastSeen)) return false;
    for (const key of DATE_KEYS) if (key in record2 && normalizeLocalDate(record2[key]) !== record2[key]) return false;
    for (const key of AMOUNT_KEYS) if (key in record2 && (typeof record2[key] !== "number" || normalizeEuroAmount(record2[key]) !== record2[key])) return false;
    if ("provider" in record2 && normalizeText(record2.provider) !== record2.provider) return false;
    if ("responseAvailable" in record2 && typeof record2.responseAvailable !== "boolean") return false;
    return true;
  }

  // src/adapter/oegk.ts
  var LIVE_ORIGIN = PRODUCTION_ORIGIN;
  var PATHS = {
    "type-range": "/vsInfo/views/KE/einreichungTyp.xhtml",
    results: "/vsInfo/views/KE/einreichungListe.xhtml",
    "open-rejected-detail": "/vsInfo/views/KE/einreichungDetailOA.xhtml",
    "reimbursed-detail": "/vsInfo/views/KE/einreichungDetail.xhtml"
  };
  function statusHeadings(labels) {
    return /* @__PURE__ */ new Map([
      [labels.openClaims, "processing"],
      [labels.rejectedClaims, "rejected"],
      [labels.reimbursedClaims, "completed"]
    ]);
  }
  function shown(element) {
    if (element.closest('[hidden], [aria-hidden="true"]')) return false;
    const view = element.ownerDocument.defaultView;
    for (let node = element; node; node = node.parentElement) {
      const style = view?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden") return false;
    }
    return true;
  }
  function exactText(element, expected) {
    return normalizeText(element?.textContent) === expected;
  }
  function hasHeading(document2, level, expected) {
    return Array.from(document2.querySelectorAll(level)).some((heading) => exactText(heading, expected));
  }
  function visibleText(element) {
    if (!element || !shown(element)) return void 0;
    const chunks = [];
    for (const child of Array.from(element.childNodes)) {
      if (child.nodeType === 3) {
        if (child.textContent) chunks.push(child.textContent);
      } else if (child.nodeType === 1) {
        const text2 = visibleText(child);
        if (text2) chunks.push(text2);
      }
    }
    return normalizeText(chunks.join(" "));
  }
  function knownText(value) {
    const text2 = normalizeText(value);
    if (!text2 || /^(?:-|—|n\/?a|not available|nicht verfügbar|unknown|unbekannt)$/iu.test(text2)) return void 0;
    return text2;
  }
  function labeledValues(scope, acceptedLabels) {
    const accepted = new Set(acceptedLabels);
    const values = /* @__PURE__ */ new Map();
    for (const row of Array.from(scope.querySelectorAll("tr"))) {
      if (!shown(row)) continue;
      const header = row.querySelector("th");
      const value = row.querySelector("td");
      const label = visibleText(header);
      if (!label || !accepted.has(label)) continue;
      const text2 = visibleText(value);
      if (text2) values.set(label, text2);
    }
    for (const field of Array.from(scope.querySelectorAll("dl.claim-fields > div"))) {
      if (!shown(field)) continue;
      const label = visibleText(field.querySelector("dt"));
      if (!label || !accepted.has(label)) continue;
      const value = visibleText(field.querySelector("dd"));
      if (value) values.set(label, value);
    }
    return values;
  }
  function hasVisibleLabel(scope, expected) {
    return Array.from(scope.querySelectorAll("tr, dl.claim-fields > div")).some((row) => shown(row) && visibleText(row.querySelector("th, dt")) === expected);
  }
  function allCardSections(document2) {
    return Array.from(document2.querySelectorAll(".card_container")).filter((container) => container.querySelector(".card_title h2") !== null && container.querySelector('[role="grid"].card_content') !== null);
  }
  function emptyAlert(document2, labels) {
    return Array.from(document2.querySelectorAll('#infolist.infobox.yellow[role="alert"]')).some((alert) => shown(alert) && normalizeText(alert.textContent)?.includes(labels.empty));
  }
  function inferPageKind(document2, pathname, labels) {
    if (pathname === PATHS["type-range"] && hasHeading(document2, "h1", labels.typeHeading)) {
      if (emptyAlert(document2, labels)) return "type-range";
      const form = Array.from(document2.querySelectorAll('form[method="post" i]')).find((candidate) => Array.from(candidate.querySelectorAll('a[role="tab"]')).some((tab) => exactText(tab, labels.doctorTab)) && candidate.querySelector(`input#vonDatWAH[name="vonDatWAH"][placeholder="${labels.datePlaceholder}"]`) && candidate.querySelector(`input#bisDatWAH[name="bisDatWAH"][placeholder="${labels.datePlaceholder}"]`) && Array.from(candidate.querySelectorAll('input[type="submit"], button[type="submit"]')).some((control) => control instanceof HTMLInputElement ? control.value === labels.continueSubmit : exactText(control, labels.continueSubmit)));
      if (form) return "type-range";
    }
    if (pathname === PATHS.results && hasHeading(document2, "h1", labels.resultsHeading)) return "results";
    if (pathname === PATHS["open-rejected-detail"] && hasHeading(document2, "h1", labels.detailHeading)) {
      return "open-rejected-detail";
    }
    if (pathname === PATHS["reimbursed-detail"] && hasHeading(document2, "h1", labels.detailHeading)) {
      return "reimbursed-detail";
    }
    return void 0;
  }
  function withOptional(base, key, value) {
    return value === void 0 ? base : { ...base, [key]: value };
  }
  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
  }
  function parseResultRow(row, status, labels) {
    const provider = knownText(visibleText(row.querySelector(".cb_title > h4")));
    const title = visibleText(row.querySelector(".cb_title")) ?? "";
    const invoiceMatch = new RegExp(`(?:^|\\s)${escapeRegExp(labels.invoiceDated)}\\s+(\\d{2}\\.\\d{2}\\.\\d{4})(?:\\s|$)`, "u").exec(title);
    const invoiceDate = normalizeLocalDate(invoiceMatch?.[1]);
    const values = labeledValues(row, [labels.invoiceAmount, labels.treatmentPeriod, labels.reimbursementAmount, labels.reimbursementDate]);
    const invoiceAmount = normalizeEuroAmount(values.get(labels.invoiceAmount));
    const treatment = parseTreatmentRange(values.get(labels.treatmentPeriod));
    const reimbursementAmountFromField = normalizeEuroAmount(values.get(labels.reimbursementAmount));
    let reimbursementAmount = reimbursementAmountFromField;
    if (reimbursementAmount === void 0) {
      const badge = visibleText(row.querySelector(".cb_status .badge")) ?? "";
      const amountMatch = new RegExp(`^(?:${escapeRegExp(labels.reimbursement)}\\s*(?:\u21AA\\s*)?|\u21AA\\s*)([0-9][0-9., \\u00a0\\u202f]*)\\s*\u20AC$`, "iu").exec(badge);
      reimbursementAmount = normalizeEuroAmount(amountMatch?.[1]);
    }
    const reimbursementDate = normalizeLocalDate(values.get(labels.reimbursementDate));
    if (!provider && !invoiceDate && invoiceAmount === void 0 && !treatment.start && !treatment.end && reimbursementAmount === void 0 && !reimbursementDate) return void 0;
    let observation = { status, source: "oegk" };
    observation = withOptional(observation, "provider", provider);
    observation = withOptional(observation, "invoiceDate", invoiceDate);
    observation = withOptional(observation, "invoiceAmount", invoiceAmount);
    observation = withOptional(observation, "treatmentDate", treatment.start);
    observation = withOptional(observation, "treatmentEndDate", treatment.end);
    observation = withOptional(observation, "reimbursementAmount", reimbursementAmount);
    observation = withOptional(observation, "reimbursementDate", reimbursementDate);
    return observation;
  }
  function parseRange(value) {
    if (!value) return void 0;
    return normalizeLocalDate(value);
  }
  function observedRange(document2) {
    const from = parseRange((document2.querySelector("#vonDat") ?? document2.querySelector("#vonDatWAH"))?.value);
    const to = parseRange((document2.querySelector("#bisDat") ?? document2.querySelector("#bisDatWAH"))?.value);
    return from && to ? { from, to } : void 0;
  }
  function parseTreatmentRange(value) {
    if (!value) return {};
    const dates = value.match(/(?:\d{2}\.\d{2}\.\d{4}|\d{4}-\d{2}-\d{2})/gu) ?? [];
    const start = normalizeLocalDate(dates[0]);
    const end = normalizeLocalDate(dates[1]);
    return {
      ...start ? { start } : {},
      ...end ? { end } : {}
    };
  }
  function parseDetail(document2, pageKind, labels) {
    const values = labeledValues(document2, [
      labels.provider,
      labels.invoiceAmount,
      labels.treatmentPeriod,
      labels.reimbursementAmount,
      labels.reimbursementDate,
      labels.treatmentFrom
    ]);
    const provider = knownText(values.get(labels.provider));
    const invoiceAmount = normalizeEuroAmount(values.get(labels.invoiceAmount));
    const reimbursementAmount = normalizeEuroAmount(values.get(labels.reimbursementAmount));
    const reimbursementDate = normalizeLocalDate(values.get(labels.reimbursementDate));
    const period = parseTreatmentRange(values.get(labels.treatmentPeriod));
    const fallbackStart = normalizeLocalDate(values.get(labels.treatmentFrom));
    const treatment = {
      ...period,
      ...!period.start && fallbackStart ? { start: fallbackStart } : {}
    };
    const rejected = hasVisibleLabel(document2, labels.reasonForRejection);
    const status = pageKind === "reimbursed-detail" ? "completed" : rejected ? "rejected" : "processing";
    if (!provider && invoiceAmount === void 0 && reimbursementAmount === void 0 && !reimbursementDate && !treatment.start && !treatment.end) {
      return void 0;
    }
    let observation = { status, source: "oegk" };
    observation = withOptional(observation, "provider", provider);
    observation = withOptional(observation, "invoiceAmount", invoiceAmount);
    observation = withOptional(observation, "reimbursementAmount", reimbursementAmount);
    observation = withOptional(observation, "reimbursementDate", reimbursementDate);
    observation = withOptional(observation, "treatmentDate", treatment.start);
    observation = withOptional(observation, "treatmentEndDate", treatment.end);
    return observation;
  }
  var OegkAdapter = class {
    document;
    location;
    allowedOrigin;
    labels;
    debug;
    debugLog;
    constructor(options = {}) {
      this.document = options.document ?? document;
      this.location = options.location ?? { origin: window.location.origin, pathname: window.location.pathname };
      this.allowedOrigin = options.expectedOrigin ?? options.fixtureOrigin ?? LIVE_ORIGIN;
      this.labels = labelsForOrigin(this.location.origin, options.expectedOrigin, this.document.documentElement?.lang);
      this.debug = options.debug ?? false;
      this.debugLog = options.debugLog ?? (() => void 0);
    }
    canHandlePage() {
      return this.location.origin === this.allowedOrigin && inferPageKind(this.document, this.location.pathname, this.labels) !== void 0;
    }
    async extractClaims() {
      if (this.location.origin !== this.allowedOrigin) return this.result("unsupported", false, [], 0, 0);
      const pageKind = inferPageKind(this.document, this.location.pathname, this.labels);
      const plausiblePath = Object.values(PATHS).includes(this.location.pathname);
      const loading = plausiblePath && (Array.from(this.document.querySelectorAll('[aria-busy="true"], [role="progressbar"], .loading')).some(shown) || this.document.readyState === "loading");
      if (loading) return this.result("loading", false, [], 0, 0, pageKind);
      const hasError = plausiblePath && Array.from(this.document.querySelectorAll('[role="alert"]')).some((alert) => shown(alert) && [this.labels.rangeError, this.labels.invalidEntries].some((message) => normalizeText(alert.textContent)?.includes(message)));
      if (hasError) return this.result("error", false, [], 0, 0, pageKind);
      if (!pageKind) {
        return this.result("unsupported", false, [], 0, 0);
      }
      if (pageKind === "type-range") {
        const empty = emptyAlert(this.document, this.labels);
        return this.result(empty ? "empty" : "complete", empty, [], 0, 0, pageKind, observedRange(this.document));
      }
      if (pageKind === "results") {
        const range = observedRange(this.document);
        if (emptyAlert(this.document, this.labels)) return this.result("empty", true, [], 0, 0, pageKind, range);
        const sections = allCardSections(this.document).filter(shown);
        if (!sections.length) return this.result("error", false, [], 0, 0, pageKind, range);
        const claims = [];
        let candidateCount = 0;
        let skippedCount = 0;
        for (const section of sections) {
          const heading = normalizeText(section.querySelector(".card_title h2")?.textContent) ?? "";
          const status = statusHeadings(this.labels).get(heading) ?? "unknown";
          for (const row of Array.from(section.querySelectorAll('[role="grid"].card_content [role="row"]'))) {
            if (!shown(row)) continue;
            candidateCount += 1;
            const claim = parseResultRow(row, status, this.labels);
            if (claim) claims.push(claim);
            else skippedCount += 1;
          }
        }
        if (candidateCount === 0) return this.result("loading", false, [], 0, 0, pageKind, range);
        return this.result("complete", skippedCount === 0, claims, candidateCount, skippedCount, pageKind, range);
      }
      const detail = parseDetail(this.document, pageKind, this.labels);
      return this.result(detail ? "complete" : "error", !!detail, detail ? [detail] : [], 1, detail ? 0 : 1, pageKind);
    }
    result(state, snapshotComplete, claims, candidateCount, skippedCount, pageKind, range) {
      if (this.debug) this.debugLog(`OEGK adapter: state=${state}; candidates=${candidateCount}; skipped=${skippedCount}`);
      return {
        state,
        snapshotComplete,
        observations: claims,
        diagnostics: { candidateCount, skippedCount },
        ...pageKind ? { pageKind } : {},
        ...range ? { observedRange: range } : {}
      };
    }
  };
  var OEGK_PATHS = Object.freeze({ ...PATHS });

  // src/live/reader.ts
  var nonces = /* @__PURE__ */ new WeakMap();
  var fields = [
    "provider",
    "treatmentDate",
    "treatmentEndDate",
    "invoiceDate",
    "submittedDate",
    "reimbursementDate",
    "invoiceAmount",
    "reimbursementAmount",
    "status",
    "responseAvailable",
    "source"
  ];
  function permitted(observation) {
    return Object.fromEntries(fields.flatMap((key) => observation[key] === void 0 ? [] : [[key, observation[key]]]));
  }
  function failure2(code, message) {
    return { ok: false, error: { code, message } };
  }
  var LiveClaimReader = class {
    constructor(pageDocument) {
      this.pageDocument = pageDocument;
    }
    async read() {
      const readAt = (/* @__PURE__ */ new Date()).toISOString();
      try {
        const url = new URL(this.pageDocument.URL);
        const context = resolveSiteContext(url);
        if (!context) return failure2("UNSUPPORTED_PAGE", "Unsupported OEGK page.");
        if (isSearchPending(this.pageDocument)) return failure2("PAGE_NOT_READY", "Search outcome is not yet confirmed. Do not automatically resubmit.");
        const location = { origin: url.origin, pathname: isSearchPageUrl(url.href) ? SEARCH_PAGE_PATH : url.pathname };
        const result = await new OegkAdapter({ document: this.pageDocument, location, expectedOrigin: context.origin }).extractClaims();
        if (result.state === "unsupported") return failure2("UNSUPPORTED_PAGE", "Unsupported OEGK page.");
        if (result.state === "loading" || result.pageKind === "type-range" && result.state === "complete") {
          return failure2("PAGE_NOT_READY", "The current page has no ready search results.");
        }
        if (result.state === "error" || !result.pageKind) return failure2("EXTRACTION_FAILED", "The current page could not be read or reports a validation error.");
        const observations = result.observations.map(permitted);
        if (observations.some((observation) => !isClaim({ ...observation, id: "validation", lastSeen: readAt }))) {
          return failure2("EXTRACTION_FAILED", "The current page contains invalid claim data.");
        }
        let nonce = nonces.get(this.pageDocument);
        if (!nonce) {
          nonce = crypto.randomUUID();
          nonces.set(this.pageDocument, nonce);
        }
        const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(observations)));
        const digest = Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, "0")).join("");
        if (isSearchPending(this.pageDocument)) return failure2("PAGE_NOT_READY", "A search is in progress.");
        const page = {
          scope: "current-page",
          environment: context.environment,
          pageKind: result.pageKind,
          readAt,
          completeness: result.diagnostics.skippedCount ? "partial" : "complete",
          skippedCount: result.diagnostics.skippedCount,
          ...result.observedRange ? { visibleRange: { ...result.observedRange } } : {}
        };
        return { ok: true, data: { page, claims: observations.map((observation, index) => ({
          ...observation,
          id: `live-v1-${nonce}-${digest}-${index}`,
          lastSeen: readAt
        })) } };
      } catch {
        return failure2("EXTRACTION_FAILED", "The current page could not be read.");
      }
    }
  };

  // src/webmcp/handlers.ts
  function failure3(code, message) {
    return { ok: false, error: { code, message } };
  }
  function createReadOnlyClaimTools(reader) {
    const catalog = Object.fromEntries(CLAIM_TOOL_CATALOG.map((tool) => [tool.name, tool]));
    const listClaims = {
      ...catalog.list_claims,
      async execute(input) {
        if (!isValidClaimToolInput("list_claims", input)) return failure3("INVALID_INPUT", "Invalid input.");
        const result = await reader.read();
        if (!result.ok) return result;
        return { ok: true, data: { claims: result.data.claims, count: result.data.claims.length, page: result.data.page } };
      }
    };
    const getOpenClaims = {
      ...catalog.get_open_claims,
      async execute(input) {
        if (!isValidClaimToolInput("get_open_claims", input)) return failure3("INVALID_INPUT", "Invalid input.");
        const result = await reader.read();
        if (!result.ok) return result;
        const claims = result.data.claims.filter(
          ({ status }) => status === "submitted" || status === "processing"
        );
        return { ok: true, data: { claims, count: claims.length, page: result.data.page } };
      }
    };
    const getClaim = {
      ...catalog.get_claim,
      async execute(input) {
        if (!isValidClaimToolInput("get_claim", input)) return failure3("INVALID_INPUT", "Invalid input.");
        const claimId = input.claimId;
        const result = await reader.read();
        if (!result.ok) return result;
        const claim = result.data.claims.find(({ id }) => id === claimId);
        if (!claim) return failure3("NOT_FOUND", "Claim ID is absent or expired. List the current page again.");
        return { ok: true, data: { claim, page: result.data.page } };
      }
    };
    return Object.freeze([listClaims, getOpenClaims, getClaim]);
  }

  // src/entries/content-bridge.ts
  if (isSupportedMeineSvUrl(window.location.href)) {
    publishBridgeStatus("data-oegk-content-bridge", "ready");
    const queries = createReadOnlyClaimTools(new LiveClaimReader(document));
    const dispose = installContentBridge(window, (tool, input) => tool === "search_claims" ? searchClaims(document, input) : queries.find((query) => query.name === tool).execute(input));
    disposeOnFinalPageHide(window, dispose);
  }
})();
