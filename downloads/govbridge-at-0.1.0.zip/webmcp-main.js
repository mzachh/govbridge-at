"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // node_modules/@cfworker/json-schema/dist/esm/deep-compare-strict.js
  function deepCompareStrict(a, b) {
    const typeofa = typeof a;
    if (typeofa !== typeof b) {
      return false;
    }
    if (Array.isArray(a)) {
      if (!Array.isArray(b)) {
        return false;
      }
      const length = a.length;
      if (length !== b.length) {
        return false;
      }
      for (let i = 0; i < length; i++) {
        if (!deepCompareStrict(a[i], b[i])) {
          return false;
        }
      }
      return true;
    }
    if (typeofa === "object") {
      if (!a || !b) {
        return a === b;
      }
      const aKeys = Object.keys(a);
      const bKeys = Object.keys(b);
      const length = aKeys.length;
      if (length !== bKeys.length) {
        return false;
      }
      for (const k of aKeys) {
        if (!deepCompareStrict(a[k], b[k])) {
          return false;
        }
      }
      return true;
    }
    return a === b;
  }
  var init_deep_compare_strict = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/deep-compare-strict.js"() {
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/pointer.js
  function encodePointer(p) {
    return encodeURI(escapePointer(p));
  }
  function escapePointer(p) {
    return p.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  var init_pointer = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/pointer.js"() {
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/dereference.js
  function dereference(schema, lookup = /* @__PURE__ */ Object.create(null), baseURI = initialBaseURI, basePointer = "") {
    if (schema && typeof schema === "object" && !Array.isArray(schema)) {
      const id = schema.$id || schema.id;
      if (id) {
        const url = new URL(id, baseURI.href);
        if (url.hash.length > 1) {
          lookup[url.href] = schema;
        } else {
          url.hash = "";
          if (basePointer === "") {
            baseURI = url;
          } else {
            dereference(schema, lookup, baseURI);
          }
        }
      }
    } else if (schema !== true && schema !== false) {
      return lookup;
    }
    const schemaURI = baseURI.href + (basePointer ? "#" + basePointer : "");
    if (lookup[schemaURI] !== void 0) {
      throw new Error(`Duplicate schema URI "${schemaURI}".`);
    }
    lookup[schemaURI] = schema;
    if (schema === true || schema === false) {
      return lookup;
    }
    if (schema.__absolute_uri__ === void 0) {
      Object.defineProperty(schema, "__absolute_uri__", {
        enumerable: false,
        value: schemaURI
      });
    }
    if (schema.$ref && schema.__absolute_ref__ === void 0) {
      const url = new URL(schema.$ref, baseURI.href);
      url.hash = url.hash;
      Object.defineProperty(schema, "__absolute_ref__", {
        enumerable: false,
        value: url.href
      });
    }
    if (schema.$recursiveRef && schema.__absolute_recursive_ref__ === void 0) {
      const url = new URL(schema.$recursiveRef, baseURI.href);
      url.hash = url.hash;
      Object.defineProperty(schema, "__absolute_recursive_ref__", {
        enumerable: false,
        value: url.href
      });
    }
    if (schema.$anchor) {
      const url = new URL("#" + schema.$anchor, baseURI.href);
      lookup[url.href] = schema;
    }
    for (let key in schema) {
      if (ignoredKeyword[key]) {
        continue;
      }
      const keyBase = `${basePointer}/${encodePointer(key)}`;
      const subSchema = schema[key];
      if (Array.isArray(subSchema)) {
        if (schemaArrayKeyword[key]) {
          const length = subSchema.length;
          for (let i = 0; i < length; i++) {
            dereference(subSchema[i], lookup, baseURI, `${keyBase}/${i}`);
          }
        }
      } else if (schemaMapKeyword[key]) {
        for (let subKey in subSchema) {
          dereference(subSchema[subKey], lookup, baseURI, `${keyBase}/${encodePointer(subKey)}`);
        }
      } else {
        dereference(subSchema, lookup, baseURI, keyBase);
      }
    }
    return lookup;
  }
  var schemaArrayKeyword, schemaMapKeyword, ignoredKeyword, initialBaseURI;
  var init_dereference = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/dereference.js"() {
      init_pointer();
      schemaArrayKeyword = {
        prefixItems: true,
        items: true,
        allOf: true,
        anyOf: true,
        oneOf: true
      };
      schemaMapKeyword = {
        $defs: true,
        definitions: true,
        properties: true,
        patternProperties: true,
        dependentSchemas: true
      };
      ignoredKeyword = {
        id: true,
        $id: true,
        $ref: true,
        $schema: true,
        $anchor: true,
        $vocabulary: true,
        $comment: true,
        default: true,
        enum: true,
        const: true,
        required: true,
        type: true,
        maximum: true,
        minimum: true,
        exclusiveMaximum: true,
        exclusiveMinimum: true,
        multipleOf: true,
        maxLength: true,
        minLength: true,
        pattern: true,
        format: true,
        maxItems: true,
        minItems: true,
        uniqueItems: true,
        maxProperties: true,
        minProperties: true
      };
      initialBaseURI = typeof self !== "undefined" && self.location && self.location.origin !== "null" ? new URL(self.location.origin + self.location.pathname + location.search) : new URL("https://github.com/cfworker");
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/format.js
  function bind(r) {
    return r.test.bind(r);
  }
  function isLeapYear(year) {
    return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  }
  function date(str) {
    const matches = str.match(DATE);
    if (!matches)
      return false;
    const year = +matches[1];
    const month = +matches[2];
    const day = +matches[3];
    return month >= 1 && month <= 12 && day >= 1 && day <= (month == 2 && isLeapYear(year) ? 29 : DAYS[month]);
  }
  function time(full, str) {
    const matches = str.match(TIME);
    if (!matches)
      return false;
    const hour = +matches[1];
    const minute = +matches[2];
    const second = +matches[3];
    const timeZone = !!matches[5];
    return (hour <= 23 && minute <= 59 && second <= 59 || hour == 23 && minute == 59 && second == 60) && (!full || timeZone);
  }
  function date_time(str) {
    const dateTime = str.split(DATE_TIME_SEPARATOR);
    return dateTime.length == 2 && date(dateTime[0]) && time(true, dateTime[1]);
  }
  function uri(str) {
    return NOT_URI_FRAGMENT.test(str) && URI_PATTERN.test(str);
  }
  function regex(str) {
    if (Z_ANCHOR.test(str))
      return false;
    try {
      new RegExp(str, "u");
      return true;
    } catch (e) {
      return false;
    }
  }
  var DATE, DAYS, TIME, HOSTNAME, URIREF, URITEMPLATE, URL_, UUID, JSON_POINTER, JSON_POINTER_URI_FRAGMENT, RELATIVE_JSON_POINTER, EMAIL, IPV4, IPV6, DURATION, format, DATE_TIME_SEPARATOR, NOT_URI_FRAGMENT, URI_PATTERN, Z_ANCHOR;
  var init_format = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/format.js"() {
      DATE = /^(\d\d\d\d)-(\d\d)-(\d\d)$/;
      DAYS = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      TIME = /^(\d\d):(\d\d):(\d\d)(\.\d+)?(z|[+-]\d\d(?::?\d\d)?)?$/i;
      HOSTNAME = /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i;
      URIREF = /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
      URITEMPLATE = /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i;
      URL_ = /^(?:(?:https?|ftp):\/\/)(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u{00a1}-\u{ffff}0-9]+-?)*[a-z\u{00a1}-\u{ffff}0-9]+)(?:\.(?:[a-z\u{00a1}-\u{ffff}0-9]+-?)*[a-z\u{00a1}-\u{ffff}0-9]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu;
      UUID = /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
      JSON_POINTER = /^(?:\/(?:[^~/]|~0|~1)*)*$/;
      JSON_POINTER_URI_FRAGMENT = /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i;
      RELATIVE_JSON_POINTER = /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/;
      EMAIL = (input) => {
        if (input[0] === '"')
          return false;
        const [name, host, ...rest] = input.split("@");
        if (!name || !host || rest.length !== 0 || name.length > 64 || host.length > 253)
          return false;
        if (name[0] === "." || name.endsWith(".") || name.includes(".."))
          return false;
        if (!/^[a-z0-9.-]+$/i.test(host) || !/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$/i.test(name))
          return false;
        return host.split(".").every((part) => /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/i.test(part));
      };
      IPV4 = /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
      IPV6 = /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i;
      DURATION = (input) => input.length > 1 && input.length < 80 && (/^P\d+([.,]\d+)?W$/.test(input) || /^P[\dYMDTHS]*(\d[.,]\d+)?[YMDHS]$/.test(input) && /^P([.,\d]+Y)?([.,\d]+M)?([.,\d]+D)?(T([.,\d]+H)?([.,\d]+M)?([.,\d]+S)?)?$/.test(input));
      format = {
        date,
        time: time.bind(void 0, false),
        "date-time": date_time,
        duration: DURATION,
        uri,
        "uri-reference": bind(URIREF),
        "uri-template": bind(URITEMPLATE),
        url: bind(URL_),
        email: EMAIL,
        hostname: bind(HOSTNAME),
        ipv4: bind(IPV4),
        ipv6: bind(IPV6),
        regex,
        uuid: bind(UUID),
        "json-pointer": bind(JSON_POINTER),
        "json-pointer-uri-fragment": bind(JSON_POINTER_URI_FRAGMENT),
        "relative-json-pointer": bind(RELATIVE_JSON_POINTER)
      };
      DATE_TIME_SEPARATOR = /t|\s/i;
      NOT_URI_FRAGMENT = /\/|:/;
      URI_PATTERN = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
      Z_ANCHOR = /[^\\]\\Z/;
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/types.js
  var OutputFormat;
  var init_types = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/types.js"() {
      (function(OutputFormat2) {
        OutputFormat2[OutputFormat2["Flag"] = 1] = "Flag";
        OutputFormat2[OutputFormat2["Basic"] = 2] = "Basic";
        OutputFormat2[OutputFormat2["Detailed"] = 4] = "Detailed";
      })(OutputFormat || (OutputFormat = {}));
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/ucs2-length.js
  function ucs2length(s) {
    let result = 0;
    let length = s.length;
    let index = 0;
    let charCode;
    while (index < length) {
      result++;
      charCode = s.charCodeAt(index++);
      if (charCode >= 55296 && charCode <= 56319 && index < length) {
        charCode = s.charCodeAt(index);
        if ((charCode & 64512) == 56320) {
          index++;
        }
      }
    }
    return result;
  }
  var init_ucs2_length = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/ucs2-length.js"() {
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/validate.js
  function validate(instance, schema, draft = "2019-09", lookup = dereference(schema), shortCircuit = true, recursiveAnchor = null, instanceLocation = "#", schemaLocation = "#", evaluated = /* @__PURE__ */ Object.create(null)) {
    if (schema === true) {
      return { valid: true, errors: [] };
    }
    if (schema === false) {
      return {
        valid: false,
        errors: [
          {
            instanceLocation,
            keyword: "false",
            keywordLocation: instanceLocation,
            error: "False boolean schema."
          }
        ]
      };
    }
    const rawInstanceType = typeof instance;
    let instanceType;
    switch (rawInstanceType) {
      case "boolean":
      case "number":
      case "string":
        instanceType = rawInstanceType;
        break;
      case "object":
        if (instance === null) {
          instanceType = "null";
        } else if (Array.isArray(instance)) {
          instanceType = "array";
        } else {
          instanceType = "object";
        }
        break;
      default:
        throw new Error(`Instances of "${rawInstanceType}" type are not supported.`);
    }
    const { $ref, $recursiveRef, $recursiveAnchor, type: $type, const: $const, enum: $enum, required: $required, not: $not, anyOf: $anyOf, allOf: $allOf, oneOf: $oneOf, if: $if, then: $then, else: $else, format: $format, properties: $properties, patternProperties: $patternProperties, additionalProperties: $additionalProperties, unevaluatedProperties: $unevaluatedProperties, minProperties: $minProperties, maxProperties: $maxProperties, propertyNames: $propertyNames, dependentRequired: $dependentRequired, dependentSchemas: $dependentSchemas, dependencies: $dependencies, prefixItems: $prefixItems, items: $items, additionalItems: $additionalItems, unevaluatedItems: $unevaluatedItems, contains: $contains, minContains: $minContains, maxContains: $maxContains, minItems: $minItems, maxItems: $maxItems, uniqueItems: $uniqueItems, minimum: $minimum, maximum: $maximum, exclusiveMinimum: $exclusiveMinimum, exclusiveMaximum: $exclusiveMaximum, multipleOf: $multipleOf, minLength: $minLength, maxLength: $maxLength, pattern: $pattern, __absolute_ref__, __absolute_recursive_ref__ } = schema;
    const errors = [];
    if ($recursiveAnchor === true && recursiveAnchor === null) {
      recursiveAnchor = schema;
    }
    if ($recursiveRef === "#") {
      const refSchema = recursiveAnchor === null ? lookup[__absolute_recursive_ref__] : recursiveAnchor;
      const keywordLocation = `${schemaLocation}/$recursiveRef`;
      const result = validate(instance, recursiveAnchor === null ? schema : recursiveAnchor, draft, lookup, shortCircuit, refSchema, instanceLocation, keywordLocation, evaluated);
      if (!result.valid) {
        errors.push({
          instanceLocation,
          keyword: "$recursiveRef",
          keywordLocation,
          error: "A subschema had errors."
        }, ...result.errors);
      }
    }
    if ($ref !== void 0) {
      const uri2 = __absolute_ref__ || $ref;
      const refSchema = lookup[uri2];
      if (refSchema === void 0) {
        let message = `Unresolved $ref "${$ref}".`;
        if (__absolute_ref__ && __absolute_ref__ !== $ref) {
          message += `  Absolute URI "${__absolute_ref__}".`;
        }
        message += `
Known schemas:
- ${Object.keys(lookup).join("\n- ")}`;
        throw new Error(message);
      }
      const keywordLocation = `${schemaLocation}/$ref`;
      const result = validate(instance, refSchema, draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, keywordLocation, evaluated);
      if (!result.valid) {
        errors.push({
          instanceLocation,
          keyword: "$ref",
          keywordLocation,
          error: "A subschema had errors."
        }, ...result.errors);
      }
      if (draft === "4" || draft === "7") {
        return { valid: errors.length === 0, errors };
      }
    }
    if (Array.isArray($type)) {
      let length = $type.length;
      let valid = false;
      for (let i = 0; i < length; i++) {
        if (instanceType === $type[i] || $type[i] === "integer" && instanceType === "number" && instance % 1 === 0 && instance === instance) {
          valid = true;
          break;
        }
      }
      if (!valid) {
        errors.push({
          instanceLocation,
          keyword: "type",
          keywordLocation: `${schemaLocation}/type`,
          error: `Instance type "${instanceType}" is invalid. Expected "${$type.join('", "')}".`
        });
      }
    } else if ($type === "integer") {
      if (instanceType !== "number" || instance % 1 || instance !== instance) {
        errors.push({
          instanceLocation,
          keyword: "type",
          keywordLocation: `${schemaLocation}/type`,
          error: `Instance type "${instanceType}" is invalid. Expected "${$type}".`
        });
      }
    } else if ($type !== void 0 && instanceType !== $type) {
      errors.push({
        instanceLocation,
        keyword: "type",
        keywordLocation: `${schemaLocation}/type`,
        error: `Instance type "${instanceType}" is invalid. Expected "${$type}".`
      });
    }
    if ($const !== void 0) {
      if (instanceType === "object" || instanceType === "array") {
        if (!deepCompareStrict(instance, $const)) {
          errors.push({
            instanceLocation,
            keyword: "const",
            keywordLocation: `${schemaLocation}/const`,
            error: `Instance does not match ${JSON.stringify($const)}.`
          });
        }
      } else if (instance !== $const) {
        errors.push({
          instanceLocation,
          keyword: "const",
          keywordLocation: `${schemaLocation}/const`,
          error: `Instance does not match ${JSON.stringify($const)}.`
        });
      }
    }
    if ($enum !== void 0) {
      if (instanceType === "object" || instanceType === "array") {
        if (!$enum.some((value) => deepCompareStrict(instance, value))) {
          errors.push({
            instanceLocation,
            keyword: "enum",
            keywordLocation: `${schemaLocation}/enum`,
            error: `Instance does not match any of ${JSON.stringify($enum)}.`
          });
        }
      } else if (!$enum.some((value) => instance === value)) {
        errors.push({
          instanceLocation,
          keyword: "enum",
          keywordLocation: `${schemaLocation}/enum`,
          error: `Instance does not match any of ${JSON.stringify($enum)}.`
        });
      }
    }
    if ($not !== void 0) {
      const keywordLocation = `${schemaLocation}/not`;
      const result = validate(instance, $not, draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, keywordLocation);
      if (result.valid) {
        errors.push({
          instanceLocation,
          keyword: "not",
          keywordLocation,
          error: 'Instance matched "not" schema.'
        });
      }
    }
    let subEvaluateds = [];
    if ($anyOf !== void 0) {
      const keywordLocation = `${schemaLocation}/anyOf`;
      const errorsLength = errors.length;
      let anyValid = false;
      for (let i = 0; i < $anyOf.length; i++) {
        const subSchema = $anyOf[i];
        const subEvaluated = Object.create(evaluated);
        const result = validate(instance, subSchema, draft, lookup, shortCircuit, $recursiveAnchor === true ? recursiveAnchor : null, instanceLocation, `${keywordLocation}/${i}`, subEvaluated);
        errors.push(...result.errors);
        anyValid = anyValid || result.valid;
        if (result.valid) {
          subEvaluateds.push(subEvaluated);
        }
      }
      if (anyValid) {
        errors.length = errorsLength;
      } else {
        errors.splice(errorsLength, 0, {
          instanceLocation,
          keyword: "anyOf",
          keywordLocation,
          error: "Instance does not match any subschemas."
        });
      }
    }
    if ($allOf !== void 0) {
      const keywordLocation = `${schemaLocation}/allOf`;
      const errorsLength = errors.length;
      let allValid = true;
      for (let i = 0; i < $allOf.length; i++) {
        const subSchema = $allOf[i];
        const subEvaluated = Object.create(evaluated);
        const result = validate(instance, subSchema, draft, lookup, shortCircuit, $recursiveAnchor === true ? recursiveAnchor : null, instanceLocation, `${keywordLocation}/${i}`, subEvaluated);
        errors.push(...result.errors);
        allValid = allValid && result.valid;
        if (result.valid) {
          subEvaluateds.push(subEvaluated);
        }
      }
      if (allValid) {
        errors.length = errorsLength;
      } else {
        errors.splice(errorsLength, 0, {
          instanceLocation,
          keyword: "allOf",
          keywordLocation,
          error: `Instance does not match every subschema.`
        });
      }
    }
    if ($oneOf !== void 0) {
      const keywordLocation = `${schemaLocation}/oneOf`;
      const errorsLength = errors.length;
      const matches = $oneOf.filter((subSchema, i) => {
        const subEvaluated = Object.create(evaluated);
        const result = validate(instance, subSchema, draft, lookup, shortCircuit, $recursiveAnchor === true ? recursiveAnchor : null, instanceLocation, `${keywordLocation}/${i}`, subEvaluated);
        errors.push(...result.errors);
        if (result.valid) {
          subEvaluateds.push(subEvaluated);
        }
        return result.valid;
      }).length;
      if (matches === 1) {
        errors.length = errorsLength;
      } else {
        errors.splice(errorsLength, 0, {
          instanceLocation,
          keyword: "oneOf",
          keywordLocation,
          error: `Instance does not match exactly one subschema (${matches} matches).`
        });
      }
    }
    if (instanceType === "object" || instanceType === "array") {
      Object.assign(evaluated, ...subEvaluateds);
    }
    if ($if !== void 0) {
      const keywordLocation = `${schemaLocation}/if`;
      const conditionResult = validate(instance, $if, draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, keywordLocation, evaluated).valid;
      if (conditionResult) {
        if ($then !== void 0) {
          const thenResult = validate(instance, $then, draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, `${schemaLocation}/then`, evaluated);
          if (!thenResult.valid) {
            errors.push({
              instanceLocation,
              keyword: "if",
              keywordLocation,
              error: `Instance does not match "then" schema.`
            }, ...thenResult.errors);
          }
        }
      } else if ($else !== void 0) {
        const elseResult = validate(instance, $else, draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, `${schemaLocation}/else`, evaluated);
        if (!elseResult.valid) {
          errors.push({
            instanceLocation,
            keyword: "if",
            keywordLocation,
            error: `Instance does not match "else" schema.`
          }, ...elseResult.errors);
        }
      }
    }
    if (instanceType === "object") {
      if ($required !== void 0) {
        for (const key of $required) {
          if (!(key in instance)) {
            errors.push({
              instanceLocation,
              keyword: "required",
              keywordLocation: `${schemaLocation}/required`,
              error: `Instance does not have required property "${key}".`
            });
          }
        }
      }
      const keys = Object.keys(instance);
      if ($minProperties !== void 0 && keys.length < $minProperties) {
        errors.push({
          instanceLocation,
          keyword: "minProperties",
          keywordLocation: `${schemaLocation}/minProperties`,
          error: `Instance does not have at least ${$minProperties} properties.`
        });
      }
      if ($maxProperties !== void 0 && keys.length > $maxProperties) {
        errors.push({
          instanceLocation,
          keyword: "maxProperties",
          keywordLocation: `${schemaLocation}/maxProperties`,
          error: `Instance does not have at least ${$maxProperties} properties.`
        });
      }
      if ($propertyNames !== void 0) {
        const keywordLocation = `${schemaLocation}/propertyNames`;
        for (const key in instance) {
          const subInstancePointer = `${instanceLocation}/${encodePointer(key)}`;
          const result = validate(key, $propertyNames, draft, lookup, shortCircuit, recursiveAnchor, subInstancePointer, keywordLocation);
          if (!result.valid) {
            errors.push({
              instanceLocation,
              keyword: "propertyNames",
              keywordLocation,
              error: `Property name "${key}" does not match schema.`
            }, ...result.errors);
          }
        }
      }
      if ($dependentRequired !== void 0) {
        const keywordLocation = `${schemaLocation}/dependantRequired`;
        for (const key in $dependentRequired) {
          if (key in instance) {
            const required = $dependentRequired[key];
            for (const dependantKey of required) {
              if (!(dependantKey in instance)) {
                errors.push({
                  instanceLocation,
                  keyword: "dependentRequired",
                  keywordLocation,
                  error: `Instance has "${key}" but does not have "${dependantKey}".`
                });
              }
            }
          }
        }
      }
      if ($dependentSchemas !== void 0) {
        for (const key in $dependentSchemas) {
          const keywordLocation = `${schemaLocation}/dependentSchemas`;
          if (key in instance) {
            const result = validate(instance, $dependentSchemas[key], draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, `${keywordLocation}/${encodePointer(key)}`, evaluated);
            if (!result.valid) {
              errors.push({
                instanceLocation,
                keyword: "dependentSchemas",
                keywordLocation,
                error: `Instance has "${key}" but does not match dependant schema.`
              }, ...result.errors);
            }
          }
        }
      }
      if ($dependencies !== void 0) {
        const keywordLocation = `${schemaLocation}/dependencies`;
        for (const key in $dependencies) {
          if (key in instance) {
            const propsOrSchema = $dependencies[key];
            if (Array.isArray(propsOrSchema)) {
              for (const dependantKey of propsOrSchema) {
                if (!(dependantKey in instance)) {
                  errors.push({
                    instanceLocation,
                    keyword: "dependencies",
                    keywordLocation,
                    error: `Instance has "${key}" but does not have "${dependantKey}".`
                  });
                }
              }
            } else {
              const result = validate(instance, propsOrSchema, draft, lookup, shortCircuit, recursiveAnchor, instanceLocation, `${keywordLocation}/${encodePointer(key)}`);
              if (!result.valid) {
                errors.push({
                  instanceLocation,
                  keyword: "dependencies",
                  keywordLocation,
                  error: `Instance has "${key}" but does not match dependant schema.`
                }, ...result.errors);
              }
            }
          }
        }
      }
      const thisEvaluated = /* @__PURE__ */ Object.create(null);
      let stop = false;
      if ($properties !== void 0) {
        const keywordLocation = `${schemaLocation}/properties`;
        for (const key in $properties) {
          if (!(key in instance)) {
            continue;
          }
          const subInstancePointer = `${instanceLocation}/${encodePointer(key)}`;
          const result = validate(instance[key], $properties[key], draft, lookup, shortCircuit, recursiveAnchor, subInstancePointer, `${keywordLocation}/${encodePointer(key)}`);
          if (result.valid) {
            evaluated[key] = thisEvaluated[key] = true;
          } else {
            stop = shortCircuit;
            errors.push({
              instanceLocation,
              keyword: "properties",
              keywordLocation,
              error: `Property "${key}" does not match schema.`
            }, ...result.errors);
            if (stop)
              break;
          }
        }
      }
      if (!stop && $patternProperties !== void 0) {
        const keywordLocation = `${schemaLocation}/patternProperties`;
        for (const pattern in $patternProperties) {
          const regex2 = new RegExp(pattern, "u");
          const subSchema = $patternProperties[pattern];
          for (const key in instance) {
            if (!regex2.test(key)) {
              continue;
            }
            const subInstancePointer = `${instanceLocation}/${encodePointer(key)}`;
            const result = validate(instance[key], subSchema, draft, lookup, shortCircuit, recursiveAnchor, subInstancePointer, `${keywordLocation}/${encodePointer(pattern)}`);
            if (result.valid) {
              evaluated[key] = thisEvaluated[key] = true;
            } else {
              stop = shortCircuit;
              errors.push({
                instanceLocation,
                keyword: "patternProperties",
                keywordLocation,
                error: `Property "${key}" matches pattern "${pattern}" but does not match associated schema.`
              }, ...result.errors);
            }
          }
        }
      }
      if (!stop && $additionalProperties !== void 0) {
        const keywordLocation = `${schemaLocation}/additionalProperties`;
        for (const key in instance) {
          if (thisEvaluated[key]) {
            continue;
          }
          const subInstancePointer = `${instanceLocation}/${encodePointer(key)}`;
          const result = validate(instance[key], $additionalProperties, draft, lookup, shortCircuit, recursiveAnchor, subInstancePointer, keywordLocation);
          if (result.valid) {
            evaluated[key] = true;
          } else {
            stop = shortCircuit;
            errors.push({
              instanceLocation,
              keyword: "additionalProperties",
              keywordLocation,
              error: `Property "${key}" does not match additional properties schema.`
            }, ...result.errors);
          }
        }
      } else if (!stop && $unevaluatedProperties !== void 0) {
        const keywordLocation = `${schemaLocation}/unevaluatedProperties`;
        for (const key in instance) {
          if (!evaluated[key]) {
            const subInstancePointer = `${instanceLocation}/${encodePointer(key)}`;
            const result = validate(instance[key], $unevaluatedProperties, draft, lookup, shortCircuit, recursiveAnchor, subInstancePointer, keywordLocation);
            if (result.valid) {
              evaluated[key] = true;
            } else {
              errors.push({
                instanceLocation,
                keyword: "unevaluatedProperties",
                keywordLocation,
                error: `Property "${key}" does not match unevaluated properties schema.`
              }, ...result.errors);
            }
          }
        }
      }
    } else if (instanceType === "array") {
      if ($maxItems !== void 0 && instance.length > $maxItems) {
        errors.push({
          instanceLocation,
          keyword: "maxItems",
          keywordLocation: `${schemaLocation}/maxItems`,
          error: `Array has too many items (${instance.length} > ${$maxItems}).`
        });
      }
      if ($minItems !== void 0 && instance.length < $minItems) {
        errors.push({
          instanceLocation,
          keyword: "minItems",
          keywordLocation: `${schemaLocation}/minItems`,
          error: `Array has too few items (${instance.length} < ${$minItems}).`
        });
      }
      const length = instance.length;
      let i = 0;
      let stop = false;
      if ($prefixItems !== void 0) {
        const keywordLocation = `${schemaLocation}/prefixItems`;
        const length2 = Math.min($prefixItems.length, length);
        for (; i < length2; i++) {
          const result = validate(instance[i], $prefixItems[i], draft, lookup, shortCircuit, recursiveAnchor, `${instanceLocation}/${i}`, `${keywordLocation}/${i}`);
          evaluated[i] = true;
          if (!result.valid) {
            stop = shortCircuit;
            errors.push({
              instanceLocation,
              keyword: "prefixItems",
              keywordLocation,
              error: `Items did not match schema.`
            }, ...result.errors);
            if (stop)
              break;
          }
        }
      }
      if ($items !== void 0) {
        const keywordLocation = `${schemaLocation}/items`;
        if (Array.isArray($items)) {
          const length2 = Math.min($items.length, length);
          for (; i < length2; i++) {
            const result = validate(instance[i], $items[i], draft, lookup, shortCircuit, recursiveAnchor, `${instanceLocation}/${i}`, `${keywordLocation}/${i}`);
            evaluated[i] = true;
            if (!result.valid) {
              stop = shortCircuit;
              errors.push({
                instanceLocation,
                keyword: "items",
                keywordLocation,
                error: `Items did not match schema.`
              }, ...result.errors);
              if (stop)
                break;
            }
          }
        } else {
          for (; i < length; i++) {
            const result = validate(instance[i], $items, draft, lookup, shortCircuit, recursiveAnchor, `${instanceLocation}/${i}`, keywordLocation);
            evaluated[i] = true;
            if (!result.valid) {
              stop = shortCircuit;
              errors.push({
                instanceLocation,
                keyword: "items",
                keywordLocation,
                error: `Items did not match schema.`
              }, ...result.errors);
              if (stop)
                break;
            }
          }
        }
        if (!stop && $additionalItems !== void 0) {
          const keywordLocation2 = `${schemaLocation}/additionalItems`;
          for (; i < length; i++) {
            const result = validate(instance[i], $additionalItems, draft, lookup, shortCircuit, recursiveAnchor, `${instanceLocation}/${i}`, keywordLocation2);
            evaluated[i] = true;
            if (!result.valid) {
              stop = shortCircuit;
              errors.push({
                instanceLocation,
                keyword: "additionalItems",
                keywordLocation: keywordLocation2,
                error: `Items did not match additional items schema.`
              }, ...result.errors);
            }
          }
        }
      }
      if ($contains !== void 0) {
        if (length === 0 && $minContains === void 0) {
          errors.push({
            instanceLocation,
            keyword: "contains",
            keywordLocation: `${schemaLocation}/contains`,
            error: `Array is empty. It must contain at least one item matching the schema.`
          });
        } else if ($minContains !== void 0 && length < $minContains) {
          errors.push({
            instanceLocation,
            keyword: "minContains",
            keywordLocation: `${schemaLocation}/minContains`,
            error: `Array has less items (${length}) than minContains (${$minContains}).`
          });
        } else {
          const keywordLocation = `${schemaLocation}/contains`;
          const errorsLength = errors.length;
          let contained = 0;
          for (let j = 0; j < length; j++) {
            const result = validate(instance[j], $contains, draft, lookup, shortCircuit, recursiveAnchor, `${instanceLocation}/${j}`, keywordLocation);
            if (result.valid) {
              evaluated[j] = true;
              contained++;
            } else {
              errors.push(...result.errors);
            }
          }
          if (contained >= ($minContains || 0)) {
            errors.length = errorsLength;
          }
          if ($minContains === void 0 && $maxContains === void 0 && contained === 0) {
            errors.splice(errorsLength, 0, {
              instanceLocation,
              keyword: "contains",
              keywordLocation,
              error: `Array does not contain item matching schema.`
            });
          } else if ($minContains !== void 0 && contained < $minContains) {
            errors.push({
              instanceLocation,
              keyword: "minContains",
              keywordLocation: `${schemaLocation}/minContains`,
              error: `Array must contain at least ${$minContains} items matching schema. Only ${contained} items were found.`
            });
          } else if ($maxContains !== void 0 && contained > $maxContains) {
            errors.push({
              instanceLocation,
              keyword: "maxContains",
              keywordLocation: `${schemaLocation}/maxContains`,
              error: `Array may contain at most ${$maxContains} items matching schema. ${contained} items were found.`
            });
          }
        }
      }
      if (!stop && $unevaluatedItems !== void 0) {
        const keywordLocation = `${schemaLocation}/unevaluatedItems`;
        for (i; i < length; i++) {
          if (evaluated[i]) {
            continue;
          }
          const result = validate(instance[i], $unevaluatedItems, draft, lookup, shortCircuit, recursiveAnchor, `${instanceLocation}/${i}`, keywordLocation);
          evaluated[i] = true;
          if (!result.valid) {
            errors.push({
              instanceLocation,
              keyword: "unevaluatedItems",
              keywordLocation,
              error: `Items did not match unevaluated items schema.`
            }, ...result.errors);
          }
        }
      }
      if ($uniqueItems) {
        for (let j = 0; j < length; j++) {
          const a = instance[j];
          const ao = typeof a === "object" && a !== null;
          for (let k = 0; k < length; k++) {
            if (j === k) {
              continue;
            }
            const b = instance[k];
            const bo = typeof b === "object" && b !== null;
            if (a === b || ao && bo && deepCompareStrict(a, b)) {
              errors.push({
                instanceLocation,
                keyword: "uniqueItems",
                keywordLocation: `${schemaLocation}/uniqueItems`,
                error: `Duplicate items at indexes ${j} and ${k}.`
              });
              j = Number.MAX_SAFE_INTEGER;
              k = Number.MAX_SAFE_INTEGER;
            }
          }
        }
      }
    } else if (instanceType === "number") {
      if (draft === "4") {
        if ($minimum !== void 0 && ($exclusiveMinimum === true && instance <= $minimum || instance < $minimum)) {
          errors.push({
            instanceLocation,
            keyword: "minimum",
            keywordLocation: `${schemaLocation}/minimum`,
            error: `${instance} is less than ${$exclusiveMinimum ? "or equal to " : ""} ${$minimum}.`
          });
        }
        if ($maximum !== void 0 && ($exclusiveMaximum === true && instance >= $maximum || instance > $maximum)) {
          errors.push({
            instanceLocation,
            keyword: "maximum",
            keywordLocation: `${schemaLocation}/maximum`,
            error: `${instance} is greater than ${$exclusiveMaximum ? "or equal to " : ""} ${$maximum}.`
          });
        }
      } else {
        if ($minimum !== void 0 && instance < $minimum) {
          errors.push({
            instanceLocation,
            keyword: "minimum",
            keywordLocation: `${schemaLocation}/minimum`,
            error: `${instance} is less than ${$minimum}.`
          });
        }
        if ($maximum !== void 0 && instance > $maximum) {
          errors.push({
            instanceLocation,
            keyword: "maximum",
            keywordLocation: `${schemaLocation}/maximum`,
            error: `${instance} is greater than ${$maximum}.`
          });
        }
        if ($exclusiveMinimum !== void 0 && instance <= $exclusiveMinimum) {
          errors.push({
            instanceLocation,
            keyword: "exclusiveMinimum",
            keywordLocation: `${schemaLocation}/exclusiveMinimum`,
            error: `${instance} is less than ${$exclusiveMinimum}.`
          });
        }
        if ($exclusiveMaximum !== void 0 && instance >= $exclusiveMaximum) {
          errors.push({
            instanceLocation,
            keyword: "exclusiveMaximum",
            keywordLocation: `${schemaLocation}/exclusiveMaximum`,
            error: `${instance} is greater than or equal to ${$exclusiveMaximum}.`
          });
        }
      }
      if ($multipleOf !== void 0) {
        const remainder = instance % $multipleOf;
        if (Math.abs(0 - remainder) >= 11920929e-14 && Math.abs($multipleOf - remainder) >= 11920929e-14) {
          errors.push({
            instanceLocation,
            keyword: "multipleOf",
            keywordLocation: `${schemaLocation}/multipleOf`,
            error: `${instance} is not a multiple of ${$multipleOf}.`
          });
        }
      }
    } else if (instanceType === "string") {
      const length = $minLength === void 0 && $maxLength === void 0 ? 0 : ucs2length(instance);
      if ($minLength !== void 0 && length < $minLength) {
        errors.push({
          instanceLocation,
          keyword: "minLength",
          keywordLocation: `${schemaLocation}/minLength`,
          error: `String is too short (${length} < ${$minLength}).`
        });
      }
      if ($maxLength !== void 0 && length > $maxLength) {
        errors.push({
          instanceLocation,
          keyword: "maxLength",
          keywordLocation: `${schemaLocation}/maxLength`,
          error: `String is too long (${length} > ${$maxLength}).`
        });
      }
      if ($pattern !== void 0 && !new RegExp($pattern, "u").test(instance)) {
        errors.push({
          instanceLocation,
          keyword: "pattern",
          keywordLocation: `${schemaLocation}/pattern`,
          error: `String does not match pattern.`
        });
      }
      if ($format !== void 0 && format[$format] && !format[$format](instance)) {
        errors.push({
          instanceLocation,
          keyword: "format",
          keywordLocation: `${schemaLocation}/format`,
          error: `String does not match format "${$format}".`
        });
      }
    }
    return { valid: errors.length === 0, errors };
  }
  var init_validate = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/validate.js"() {
      init_deep_compare_strict();
      init_dereference();
      init_format();
      init_pointer();
      init_ucs2_length();
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/validator.js
  var Validator;
  var init_validator = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/validator.js"() {
      init_dereference();
      init_validate();
      Validator = class {
        schema;
        draft;
        shortCircuit;
        lookup;
        constructor(schema, draft = "2019-09", shortCircuit = true) {
          this.schema = schema;
          this.draft = draft;
          this.shortCircuit = shortCircuit;
          this.lookup = dereference(schema);
        }
        validate(instance) {
          return validate(instance, this.schema, this.draft, this.lookup, this.shortCircuit);
        }
        addSchema(schema, id) {
          if (id) {
            schema = { ...schema, $id: id };
          }
          dereference(schema, this.lookup);
        }
      };
    }
  });

  // node_modules/@cfworker/json-schema/dist/esm/index.js
  var init_esm = __esm({
    "node_modules/@cfworker/json-schema/dist/esm/index.js"() {
      init_deep_compare_strict();
      init_dereference();
      init_format();
      init_pointer();
      init_types();
      init_ucs2_length();
      init_validate();
      init_validator();
    }
  });

  // node_modules/@mcp-b/webmcp-polyfill/dist/schema.js
  function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isJsonObjectRecord(value) {
    if (!isPlainObject(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }
  function isJsonValue(value, seen = /* @__PURE__ */ new WeakSet()) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return true;
    if (typeof value === "number") return Number.isFinite(value);
    if (typeof value !== "object") return false;
    if (seen.has(value)) return false;
    seen.add(value);
    try {
      return (Array.isArray(value) ? value : isJsonObjectRecord(value) ? Object.values(value) : null)?.every((entry) => isJsonValue(entry, seen)) ?? false;
    } catch {
      return false;
    } finally {
      seen.delete(value);
    }
  }
  function toJsonValue(value) {
    return isJsonValue(value) ? value : void 0;
  }
  function getStandardProps(value) {
    if (!isPlainObject(value)) return null;
    const standard = value["~standard"];
    if (!isPlainObject(standard)) return null;
    return standard;
  }
  function isStandardInputValidatorSchema(value) {
    const standard = getStandardProps(value);
    return Boolean(standard && standard.version === 1 && typeof standard.validate === "function");
  }
  function isStandardInputJsonSchema(value) {
    const standard = getStandardProps(value);
    if (!standard || standard.version !== 1 || !isPlainObject(standard.jsonSchema)) return false;
    return typeof standard.jsonSchema.input === "function";
  }
  function createStandardValidatorFromJsonSchema(schema) {
    return { "~standard": {
      version: 1,
      vendor: "@mcp-b/webmcp-polyfill-json-schema",
      validate(value) {
        if (!isPlainObject(value)) return { issues: [{ message: "expected object arguments" }] };
        const issue = validateValueWithSchema(value, schema);
        if (issue) return { issues: [issue] };
        return { value };
      }
    } };
  }
  function convertStandardInputSchema(schema) {
    const failures = [];
    for (const target of STANDARD_JSON_SCHEMA_TARGETS) try {
      const converted = schema["~standard"].jsonSchema.input({ target });
      validateInputSchema(converted);
      return converted;
    } catch (error) {
      failures.push({
        target,
        error
      });
    }
    console.warn("[WebMCPPolyfill] Standard JSON Schema conversion failed:", failures);
    throw new Error("Failed to convert Standard JSON Schema inputSchema to a JSON Schema object");
  }
  function normalizeInputSchema(inputSchema) {
    if (inputSchema === void 0) {
      const normalized = DEFAULT_INPUT_SCHEMA;
      return {
        inputSchema: normalized,
        standardValidator: createStandardValidatorFromJsonSchema(normalized)
      };
    }
    if (isStandardInputJsonSchema(inputSchema)) {
      const converted = convertStandardInputSchema(inputSchema);
      return {
        inputSchema: converted,
        standardValidator: createStandardValidatorFromJsonSchema(converted)
      };
    }
    if (isStandardInputValidatorSchema(inputSchema)) return {
      inputSchema: DEFAULT_INPUT_SCHEMA,
      standardValidator: inputSchema
    };
    validateInputSchema(inputSchema);
    if (Object.keys(inputSchema).length === 0) return {
      inputSchema: DEFAULT_INPUT_SCHEMA,
      standardValidator: createStandardValidatorFromJsonSchema(DEFAULT_INPUT_SCHEMA)
    };
    const normalizedSchema = inputSchema.type === void 0 ? {
      type: "object",
      ...inputSchema
    } : inputSchema;
    return {
      inputSchema: normalizedSchema,
      standardValidator: createStandardValidatorFromJsonSchema(normalizedSchema)
    };
  }
  function validateInputSchema(schema) {
    if (!isPlainObject(schema)) throw new Error("inputSchema must be a JSON Schema object");
    validateJsonSchemaNode(schema, "$");
  }
  function validateJsonSchemaNode(node, path) {
    const typeValue = node.type;
    if (typeValue !== void 0 && typeof typeValue !== "string" && !(Array.isArray(typeValue) && typeValue.every((entry) => typeof entry === "string" && entry.length > 0))) throw new Error(`Invalid JSON Schema at ${path}: "type" must be a string or string[]`);
    const requiredValue = node.required;
    if (requiredValue !== void 0 && !(Array.isArray(requiredValue) && requiredValue.every((entry) => typeof entry === "string"))) throw new Error(`Invalid JSON Schema at ${path}: "required" must be an array of strings`);
    const propertiesValue = node.properties;
    if (propertiesValue !== void 0) {
      if (!isPlainObject(propertiesValue)) throw new Error(`Invalid JSON Schema at ${path}: "properties" must be an object`);
      for (const [key, value] of Object.entries(propertiesValue)) {
        if (!isPlainObject(value)) throw new Error(`Invalid JSON Schema at ${path}.properties.${key}: expected object schema`);
        validateJsonSchemaNode(value, `${path}.properties.${key}`);
      }
    }
    const itemsValue = node.items;
    if (itemsValue !== void 0) if (Array.isArray(itemsValue)) for (const [index, value] of itemsValue.entries()) {
      if (!isPlainObject(value)) throw new Error(`Invalid JSON Schema at ${path}.items[${index}]: expected object schema`);
      validateJsonSchemaNode(value, `${path}.items[${index}]`);
    }
    else if (isPlainObject(itemsValue)) validateJsonSchemaNode(itemsValue, `${path}.items`);
    else throw new Error(`Invalid JSON Schema at ${path}: "items" must be an object or object[]`);
    for (const keyword of [
      "allOf",
      "anyOf",
      "oneOf"
    ]) {
      const value = node[keyword];
      if (value === void 0) continue;
      if (!Array.isArray(value)) throw new Error(`Invalid JSON Schema at ${path}: "${keyword}" must be an array`);
      for (const [index, entry] of value.entries()) {
        if (!isPlainObject(entry)) throw new Error(`Invalid JSON Schema at ${path}.${keyword}[${index}]: expected object schema`);
        validateJsonSchemaNode(entry, `${path}.${keyword}[${index}]`);
      }
    }
    const notValue = node.not;
    if (notValue !== void 0) {
      if (!isPlainObject(notValue)) throw new Error(`Invalid JSON Schema at ${path}: "not" must be an object schema`);
      validateJsonSchemaNode(notValue, `${path}.not`);
    }
    try {
      JSON.stringify(node);
    } catch {
      throw new Error(`Invalid JSON Schema at ${path}: schema must be JSON-serializable`);
    }
  }
  function validateValueWithSchema(value, schema) {
    const result = new Validator(schema, "2020-12", true).validate(value);
    if (result.valid) return null;
    const error = result.errors[result.errors.length - 1];
    if (!error) return { message: "Input validation failed" };
    return { message: error.error };
  }
  var DEFAULT_INPUT_SCHEMA, STANDARD_JSON_SCHEMA_TARGETS;
  var init_schema = __esm({
    "node_modules/@mcp-b/webmcp-polyfill/dist/schema.js"() {
      init_esm();
      DEFAULT_INPUT_SCHEMA = {
        type: "object",
        properties: {}
      };
      STANDARD_JSON_SCHEMA_TARGETS = ["draft-2020-12", "draft-07"];
    }
  });

  // node_modules/@mcp-b/webmcp-polyfill/dist/index.js
  var dist_exports = {};
  __export(dist_exports, {
    cleanupWebMCPPolyfill: () => cleanupWebMCPPolyfill,
    initializeWebMCPPolyfill: () => initializeWebMCPPolyfill,
    initializeWebModelContextPolyfill: () => initializeWebMCPPolyfill,
    isPlainObject: () => isPlainObject,
    normalizeInputSchema: () => normalizeInputSchema,
    toJsonValue: () => toJsonValue,
    validateValueWithSchema: () => validateValueWithSchema
  });
  function createAbortError() {
    return new DOMException("signal is aborted without reason", "AbortError");
  }
  function createUnknownError(message) {
    try {
      return new DOMException(message, "UnknownError");
    } catch {
      const error = new Error(message);
      error.name = "UnknownError";
      return error;
    }
  }
  function createInvalidStateError(message) {
    try {
      return new DOMException(message, "InvalidStateError");
    } catch {
      const error = new Error(message);
      error.name = "InvalidStateError";
      return error;
    }
  }
  function parseInputArgsJson(inputArgsJson) {
    let parsed;
    try {
      parsed = JSON.parse(inputArgsJson);
    } catch {
      throw createUnknownError(FAILED_TO_PARSE_INPUT_ARGUMENTS_MESSAGE);
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw createUnknownError(FAILED_TO_PARSE_INPUT_ARGUMENTS_MESSAGE);
    return parsed;
  }
  function getToolNameForUnregister(nameOrTool) {
    if (typeof nameOrTool === "string") return nameOrTool;
    if (isPlainObject(nameOrTool) && typeof nameOrTool.name === "string") return nameOrTool.name;
    throw new TypeError("Failed to execute 'unregisterTool' on 'ModelContext': parameter 1 must be a string or an object with a string name.");
  }
  function normalizeToolDescriptor(tool, existing) {
    if (!tool || typeof tool !== "object") throw new TypeError("registerTool(tool) requires a tool object");
    if (typeof tool.name !== "string" || tool.name.length === 0) throw createInvalidStateError('Tool "name" must be a non-empty string');
    if (!VALID_TOOL_NAME_RE.test(tool.name) || Array.from(tool.name).length > 128) throw createInvalidStateError('Tool "name" must be 1\u2013128 characters and contain only ASCII alphanumeric, underscore, hyphen, or period');
    if (typeof tool.description !== "string" || tool.description.length === 0) throw createInvalidStateError('Tool "description" must be a non-empty string');
    if (typeof tool.execute !== "function") throw new TypeError('Tool "execute" must be a function');
    if (existing.has(tool.name)) throw new Error(`Tool already registered: ${tool.name}`);
    const normalizedInputSchema = normalizeInputSchema(tool.inputSchema);
    const annotations = tool.annotations;
    const normalizedAnnotations = annotations ? {
      ...annotations,
      ...annotations.readOnlyHint === "true" ? { readOnlyHint: true } : annotations.readOnlyHint === "false" ? { readOnlyHint: false } : {},
      ...annotations.destructiveHint === "true" ? { destructiveHint: true } : annotations.destructiveHint === "false" ? { destructiveHint: false } : {},
      ...annotations.idempotentHint === "true" ? { idempotentHint: true } : annotations.idempotentHint === "false" ? { idempotentHint: false } : {},
      ...annotations.openWorldHint === "true" ? { openWorldHint: true } : annotations.openWorldHint === "false" ? { openWorldHint: false } : {}
    } : void 0;
    return {
      ...tool,
      ...normalizedAnnotations ? { annotations: normalizedAnnotations } : {},
      inputSchema: normalizedInputSchema.inputSchema,
      [STANDARD_VALIDATOR_SYMBOL]: normalizedInputSchema.standardValidator
    };
  }
  function formatStandardIssuePath(path) {
    if (!path || path.length === 0) return null;
    const segments = path.map((segment) => {
      if (isPlainObject(segment) && "key" in segment) return segment.key;
      return segment;
    }).map((segment) => String(segment)).filter((segment) => segment.length > 0);
    if (segments.length === 0) return null;
    return segments.join(".");
  }
  async function validateArgsWithStandardSchema(args, schema) {
    let result;
    try {
      result = await Promise.resolve(schema["~standard"].validate(args));
    } catch (error) {
      const detail = error instanceof Error ? `: ${error.message}` : "";
      console.error("[WebMCPPolyfill] Standard Schema validation threw unexpectedly:", error);
      return `Input validation error: schema validation failed${detail}`;
    }
    if (!result.issues || result.issues.length === 0) return null;
    const firstIssue = result.issues[0];
    if (!firstIssue) return "Input validation error";
    const path = formatStandardIssuePath(firstIssue?.path);
    if (path) return `Input validation error: ${firstIssue.message} at ${path}`;
    return `Input validation error: ${firstIssue.message}`;
  }
  async function validateArgsForTool(args, tool) {
    return validateArgsWithStandardSchema(args, tool[STANDARD_VALIDATOR_SYMBOL]);
  }
  function validateOutputForTool(result, tool) {
    if (!tool.outputSchema || result.isError) return null;
    if (result.structuredContent === void 0) return `Output validation error: Tool ${tool.name} has an output schema but no structured content was provided`;
    const issue = validateValueWithSchema(result.structuredContent, tool.outputSchema);
    return issue ? `Output validation error: ${issue.message}` : null;
  }
  function isCallToolResult(value) {
    return isPlainObject(value) && Array.isArray(value.content);
  }
  function serializeTextContent(value) {
    if (typeof value === "string") return value;
    try {
      return JSON.stringify(value) ?? String(value);
    } catch {
      return String(value);
    }
  }
  function normalizeToolResponse(value) {
    if (isCallToolResult(value)) return value;
    const structuredContent = toJsonValue(value);
    return {
      content: [{
        type: "text",
        text: serializeTextContent(value)
      }],
      ...structuredContent !== void 0 ? { structuredContent } : {},
      isError: false
    };
  }
  function getFirstTextBlock(result) {
    for (const block of result.content ?? []) if (block.type === "text" && "text" in block && typeof block.text === "string") return block.text;
    return null;
  }
  function toSerializedTestingResult(result) {
    if (result.isError) throw createUnknownError(getFirstTextBlock(result)?.replace(/^Error:\s*/i, "").trim() || TOOL_INVOCATION_FAILED_MESSAGE);
    const metadata = result.metadata;
    if (metadata && typeof metadata === "object" && metadata.willNavigate) return null;
    try {
      return JSON.stringify(result);
    } catch {
      throw createUnknownError(TOOL_INVOCATION_FAILED_MESSAGE);
    }
  }
  function withAbortSignal(operation, signal) {
    if (!signal) return operation;
    if (signal.aborted) return Promise.reject(createUnknownError(TOOL_CANCELLED_MESSAGE));
    return new Promise((resolve, reject) => {
      const onAbort = () => {
        cleanup();
        reject(createUnknownError(TOOL_CANCELLED_MESSAGE));
      };
      const cleanup = () => {
        signal.removeEventListener("abort", onAbort);
      };
      signal.addEventListener("abort", onAbort, { once: true });
      operation.then((value) => {
        cleanup();
        resolve(value);
      }, (error) => {
        cleanup();
        reject(error);
      });
    });
  }
  function getNavigator() {
    if (typeof navigator !== "undefined") return navigator;
    return null;
  }
  function getDocument() {
    if (typeof document !== "undefined") return document;
    return null;
  }
  function defineNavigatorProperty(target, key, value) {
    Object.defineProperty(target, key, {
      configurable: true,
      enumerable: true,
      writable: false,
      value
    });
  }
  function defineDocumentModelContextProperty(target, value) {
    Object.defineProperty(target, "modelContext", {
      configurable: true,
      enumerable: true,
      writable: false,
      value
    });
  }
  function defineDeprecatedNavigatorModelContext(target, value) {
    Object.defineProperty(target, "modelContext", {
      configurable: true,
      enumerable: true,
      get() {
        if (!navigatorModelContextDeprecationWarned) {
          navigatorModelContextDeprecationWarned = true;
          console.warn("[WebMCPPolyfill] navigator.modelContext is deprecated. The May 27, 2026 WebMCP draft moved the modelContext getter from Navigator to Document \u2014 use document.modelContext instead. See https://github.com/webmachinelearning/webmcp/pull/184.");
        }
        return value;
      }
    });
  }
  function initializeWebMCPPolyfill(options) {
    const nav = getNavigator();
    const doc = getDocument();
    if (!nav && !doc) return;
    const documentModelContext = doc?.modelContext;
    if (Boolean(documentModelContext)) return;
    const navigatorModelContext = nav?.modelContext;
    const hasNavigatorModelContext = Boolean(navigatorModelContext);
    if (installState.installed) cleanupWebMCPPolyfill();
    if (doc && navigatorModelContext) {
      installState.previousDocumentModelContextDescriptor = Object.getOwnPropertyDescriptor(doc, "modelContext");
      defineDocumentModelContextProperty(doc, navigatorModelContext);
      installState.installedDocumentModelContext = true;
      installState.installed = true;
      return;
    }
    if (hasNavigatorModelContext) return;
    const context = new StrictWebMCPContext();
    const modelContext = context;
    modelContext[POLYFILL_MARKER_PROPERTY] = true;
    if (doc) {
      installState.previousDocumentModelContextDescriptor = Object.getOwnPropertyDescriptor(doc, "modelContext");
      defineDocumentModelContextProperty(doc, modelContext);
      installState.installedDocumentModelContext = true;
    }
    if (nav) {
      installState.previousNavigatorModelContextDescriptor = Object.getOwnPropertyDescriptor(nav, "modelContext");
      installState.previousNavigatorModelContextTestingDescriptor = Object.getOwnPropertyDescriptor(nav, "modelContextTesting");
      navigatorModelContextDeprecationWarned = false;
      defineDeprecatedNavigatorModelContext(nav, modelContext);
      installState.installedNavigatorModelContext = true;
      const installTestingShim = options?.installTestingShim ?? "if-missing";
      const hasModelContextTesting = Boolean(nav.modelContextTesting);
      if (installTestingShim === "always" || (installTestingShim === true || installTestingShim === "if-missing") && !hasModelContextTesting) {
        defineNavigatorProperty(nav, "modelContextTesting", context.getTestingShim());
        installState.installedNavigatorModelContextTesting = true;
      }
    }
    installState.installed = true;
  }
  function cleanupWebMCPPolyfill() {
    if (!installState.installed) return;
    const restore = (target, key, previousDescriptor) => {
      if (previousDescriptor) {
        Object.defineProperty(target, key, previousDescriptor);
        return;
      }
      delete target[key];
    };
    const nav = getNavigator();
    const doc = getDocument();
    if (doc && installState.installedDocumentModelContext) restore(doc, "modelContext", installState.previousDocumentModelContextDescriptor);
    if (nav && installState.installedNavigatorModelContext) restore(nav, "modelContext", installState.previousNavigatorModelContextDescriptor);
    if (nav && installState.installedNavigatorModelContextTesting) restore(nav, "modelContextTesting", installState.previousNavigatorModelContextTestingDescriptor);
    installState.installed = false;
    installState.previousDocumentModelContextDescriptor = void 0;
    installState.previousNavigatorModelContextDescriptor = void 0;
    installState.previousNavigatorModelContextTestingDescriptor = void 0;
    installState.installedDocumentModelContext = false;
    installState.installedNavigatorModelContext = false;
    installState.installedNavigatorModelContextTesting = false;
    navigatorModelContextDeprecationWarned = false;
  }
  var FAILED_TO_PARSE_INPUT_ARGUMENTS_MESSAGE, TOOL_INVOCATION_FAILED_MESSAGE, TOOL_CANCELLED_MESSAGE, VALID_TOOL_NAME_RE, POLYFILL_MARKER_PROPERTY, STANDARD_VALIDATOR_SYMBOL, installState, StrictWebMCPContext, PolyfillTestingShim, navigatorModelContextDeprecationWarned;
  var init_dist = __esm({
    "node_modules/@mcp-b/webmcp-polyfill/dist/index.js"() {
      init_schema();
      FAILED_TO_PARSE_INPUT_ARGUMENTS_MESSAGE = "Failed to parse input arguments";
      TOOL_INVOCATION_FAILED_MESSAGE = "Tool was executed but the invocation failed. For example, the script function threw an error";
      TOOL_CANCELLED_MESSAGE = "Tool was cancelled";
      VALID_TOOL_NAME_RE = /^[A-Za-z0-9_\-.]{1,128}$/u;
      POLYFILL_MARKER_PROPERTY = "__isWebMCPPolyfill";
      STANDARD_VALIDATOR_SYMBOL = Symbol("standardValidator");
      installState = {
        installed: false,
        previousNavigatorModelContextDescriptor: void 0,
        previousNavigatorModelContextTestingDescriptor: void 0,
        previousDocumentModelContextDescriptor: void 0,
        installedNavigatorModelContext: false,
        installedNavigatorModelContextTesting: false,
        installedDocumentModelContext: false
      };
      StrictWebMCPContext = class extends EventTarget {
        tools = /* @__PURE__ */ new Map();
        testingShim = null;
        _ontoolchange = null;
        unregisterToolDeprecationWarned = false;
        toolsChangedQueued = false;
        get ontoolchange() {
          return this._ontoolchange;
        }
        set ontoolchange(handler) {
          this._ontoolchange = handler;
        }
        registerTool(tool, options) {
          const signal = options?.signal;
          if (signal?.aborted) return Promise.reject(createAbortError());
          const normalized = normalizeToolDescriptor(tool, this.tools);
          this.tools.set(normalized.name, normalized);
          this.notifyToolsChanged();
          if (signal) signal.addEventListener("abort", () => {
            if (this.tools.delete(normalized.name)) this.notifyToolsChanged();
          }, { once: true });
          return Promise.resolve();
        }
        unregisterTool(nameOrTool) {
          this.warnUnregisterToolDeprecationOnce();
          const name = getToolNameForUnregister(nameOrTool);
          if (this.tools.delete(name)) this.notifyToolsChanged();
        }
        getTools() {
          return Promise.resolve(this.getRegisteredToolInfos());
        }
        executeTool(tool, inputArgsJson, options) {
          return this.executeToolByName(tool.name, inputArgsJson, options, false);
        }
        getTestingShim() {
          if (!this.testingShim) this.testingShim = new PolyfillTestingShim(this);
          return this.testingShim;
        }
        /** @internal Used by PolyfillTestingShim */
        getToolInfos() {
          return [...this.tools.values()].map((tool) => {
            let inputSchema;
            try {
              inputSchema = JSON.stringify(tool.inputSchema ?? { type: "object" });
            } catch {
              inputSchema = '{"type":"object"}';
            }
            return {
              name: tool.name,
              description: tool.description,
              inputSchema
            };
          });
        }
        /** @internal Used by getTools() */
        getRegisteredToolInfos() {
          return this.getToolInfos().map((toolInfo) => {
            const tool = this.tools.get(toolInfo.name);
            return {
              ...toolInfo,
              title: tool?.title ?? "",
              origin: globalThis.location?.origin ?? "",
              window: globalThis.window
            };
          });
        }
        /** @internal Used by PolyfillTestingShim */
        async executeToolForTesting(toolName, inputArgsJson, options) {
          return this.executeToolByName(toolName, inputArgsJson, options, true);
        }
        async executeToolByName(toolName, inputArgsJson, options, normalizeResult) {
          if (options?.signal?.aborted) throw createUnknownError(TOOL_CANCELLED_MESSAGE);
          const tool = this.tools.get(toolName);
          if (!tool) throw createUnknownError(`Tool not found: ${toolName}`);
          const args = parseInputArgsJson(inputArgsJson);
          const validationError = await validateArgsForTool(args, tool);
          if (validationError) throw createUnknownError(validationError);
          let contextActive = true;
          const client = { requestUserInteraction: async (callback) => {
            if (!contextActive) throw new Error(`ModelContextClient for tool "${toolName}" is no longer active after execute() resolved`);
            if (typeof callback !== "function") throw new TypeError("requestUserInteraction(callback) requires a function callback");
            return callback();
          } };
          try {
            const execution = tool.execute(args, client);
            const rawResult = await withAbortSignal(Promise.resolve(execution), options?.signal);
            const normalizedResult = normalizeToolResponse(rawResult);
            const outputValidationError = validateOutputForTool(normalizedResult, tool);
            if (outputValidationError) throw new Error(outputValidationError);
            if (normalizeResult) return toSerializedTestingResult(normalizedResult);
            const serialized = JSON.stringify(rawResult);
            return serialized === void 0 ? null : serialized;
          } catch (error) {
            throw createUnknownError(error instanceof Error ? `${TOOL_INVOCATION_FAILED_MESSAGE}: ${error.message}` : TOOL_INVOCATION_FAILED_MESSAGE);
          } finally {
            contextActive = false;
          }
        }
        notifyToolsChanged() {
          if (this.toolsChangedQueued) return;
          this.toolsChangedQueued = true;
          queueMicrotask(() => {
            this.toolsChangedQueued = false;
            const event = new Event("toolchange");
            try {
              this._ontoolchange?.call(this, event);
            } catch (error) {
              console.warn("[WebMCPPolyfill] navigator.modelContext.ontoolchange handler threw:", error);
            }
            this.dispatchEvent(event);
            this.testingShim?.dispatchToolChange();
          });
        }
        warnUnregisterToolDeprecationOnce() {
          if (this.unregisterToolDeprecationWarned) return;
          this.unregisterToolDeprecationWarned = true;
          console.warn("[WebMCPPolyfill] navigator.modelContext.unregisterTool() is deprecated. The April 23, 2026 WebMCP draft removed it in favor of registerTool(tool, { signal }) \u2014 pass an AbortSignal and abort it to unregister.");
        }
      };
      PolyfillTestingShim = class extends EventTarget {
        context;
        _ontoolchange = null;
        constructor(context) {
          super();
          this.context = context;
        }
        listTools() {
          return this.context.getToolInfos();
        }
        executeTool(toolName, inputArgsJson, options) {
          return this.context.executeToolForTesting(toolName, inputArgsJson, options);
        }
        getCrossDocumentScriptToolResult() {
          return Promise.resolve("[]");
        }
        get ontoolchange() {
          return this._ontoolchange;
        }
        set ontoolchange(handler) {
          this._ontoolchange = handler;
        }
        /**
        * @deprecated Use `addEventListener('toolchange', callback)` instead.
        * Kept for backward compatibility with older polyfill consumers.
        */
        registerToolsChangedCallback(callback) {
          if (typeof callback !== "function") throw new TypeError("Failed to execute 'registerToolsChangedCallback' on 'ModelContextTesting': parameter 1 is not of type 'Function'.");
          this.addEventListener("toolchange", callback);
        }
        /** @internal Called by StrictWebMCPContext when tools change. */
        dispatchToolChange() {
          const event = new Event("toolchange");
          try {
            this._ontoolchange?.call(this, event);
          } catch (error) {
            console.warn("[WebMCPPolyfill] ontoolchange handler threw:", error);
          }
          this.dispatchEvent(event);
          this.dispatchEvent(new Event("toolschanged"));
        }
      };
      navigatorModelContextDeprecationWarned = false;
      if (typeof window !== "undefined" && typeof document !== "undefined") {
        const options = window.__webMCPPolyfillOptions;
        if (options?.autoInitialize !== false) try {
          initializeWebMCPPolyfill(options);
        } catch (error) {
          console.error("[WebMCPPolyfill] Auto-initialization failed:", error);
        }
      }
    }
  });

  // config/extension-targets.json
  var extension_targets_default = {
    productionOrigin: "https://www.meinesv.at",
    demoOrigin: "https://govbridge-at-demo.manuel857067.chatgpt.site",
    developmentOrigins: [
      "http://localhost:4173",
      "http://127.0.0.1:4173"
    ]
  };

  // src/environment/site-context.ts
  var SITE_ENVIRONMENTS = ["production", "demo", "development"];
  var EXTENSION_TARGETS = Object.freeze({
    productionOrigin: extension_targets_default.productionOrigin,
    demoOrigin: extension_targets_default.demoOrigin,
    developmentOrigins: Object.freeze([...extension_targets_default.developmentOrigins])
  });
  var PRODUCTION_ORIGIN = EXTENSION_TARGETS.productionOrigin;
  var DEMO_ORIGIN = EXTENSION_TARGETS.demoOrigin ?? void 0;
  var DEVELOPMENT_ORIGINS = EXTENSION_TARGETS.developmentOrigins;
  var SYNTHETIC_DEMO_NOTICE = "Synthetic demo data only \u2014 not MeineSV or OEGK.";
  function configuredBuildProfile() {
    return ["extension", ...SITE_ENVIRONMENTS].includes("extension") ? "extension" : "extension";
  }
  var BUILD_PROFILE = configuredBuildProfile();
  function exactOrigin(rawOrigin) {
    try {
      const parsed = new URL(rawOrigin);
      if (parsed.origin !== rawOrigin || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) return void 0;
      return parsed.origin;
    } catch {
      return void 0;
    }
  }
  function isLoopbackDevelopmentOrigin(origin) {
    try {
      const parsed = new URL(origin);
      return parsed.protocol === "http:" && (parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1") && parsed.port === "4173" && exactOrigin(origin) !== void 0;
    } catch {
      return false;
    }
  }
  function originContexts() {
    const contexts = [];
    const production = exactOrigin(PRODUCTION_ORIGIN);
    if (production) contexts.push({ origin: production, environment: "production" });
    const demo = DEMO_ORIGIN && exactOrigin(DEMO_ORIGIN);
    if (demo && demo !== production && demo.startsWith("https://")) {
      contexts.push({ origin: demo, environment: "demo" });
    }
    for (const origin of DEVELOPMENT_ORIGINS) {
      if (isLoopbackDevelopmentOrigin(origin) && !contexts.some((context) => context.origin === origin)) {
        contexts.push({ origin, environment: "development" });
      }
    }
    return contexts;
  }
  function profileAllowsEnvironment(profile, environment) {
    return ["extension", ...SITE_ENVIRONMENTS].includes(profile) && SITE_ENVIRONMENTS.includes(environment);
  }
  function resolveSiteContext(rawUrl, profile = BUILD_PROFILE) {
    if (!rawUrl) return void 0;
    try {
      const url = new URL(rawUrl);
      const origin = url.origin;
      const context = originContexts().find((candidate) => candidate.origin === origin);
      return context && profileAllowsEnvironment(profile, context.environment) ? context : void 0;
    } catch {
      return void 0;
    }
  }

  // src/webmcp/catalog.ts
  var EMPTY_INPUT_SCHEMA = Object.freeze({
    type: "object",
    properties: Object.freeze({}),
    additionalProperties: false
  });
  var CLAIM_ID_INPUT_SCHEMA = Object.freeze({
    type: "object",
    required: Object.freeze(["claimId"]),
    properties: Object.freeze({
      claimId: Object.freeze({ type: "string", minLength: 1, maxLength: 256 })
    }),
    additionalProperties: false
  });
  var CLAIM_TOOL_CATALOG = Object.freeze([
    Object.freeze({
      name: "list_claims",
      description: "Read OEGK claims rendered on the current page now, in page order. No refresh or stored history. Results include current-page completeness; IDs are temporary.",
      inputSchema: EMPTY_INPUT_SCHEMA
    }),
    Object.freeze({
      name: "get_open_claims",
      description: "Read the current OEGK page and return claims whose status is submitted or processing. Current-page scope only.",
      inputSchema: EMPTY_INPUT_SCHEMA
    }),
    Object.freeze({
      name: "get_claim",
      description: "Read the current OEGK page and find a temporary snapshot claim ID. Never navigates. If NOT_FOUND, list again.",
      inputSchema: CLAIM_ID_INPUT_SCHEMA
    })
  ]);
  var SEARCH_PAGE_PATH = "/vsInfo/views/KE/einreichungTyp.xhtml";
  var SEARCH_ENTRY_PATH = "/vsInfo/views/KE/";
  var SEARCH_RESULTS_PATH = "/vsInfo/views/KE/einreichungListe.xhtml";
  var SEARCH_CONTENT_ID = "10007.815943";
  var SEARCH_TOOL = Object.freeze({
    name: "search_claims",
    description: "Request a Wahlarzt / Wahltherapeut search on MeineSV for inclusive ISO dates, at most five calendar years. Registered on query and results routes; execution requires the validated query form or retained results-range form. Submits the current form once; does not return claims or confirm success. Navigation may return null or destroy execution. Never automatically retry an uncertain submission; cancellation cannot undo a dispatched click.",
    inputSchema: Object.freeze({
      type: "object",
      required: Object.freeze(["from", "to"]),
      properties: Object.freeze({
        from: Object.freeze({ type: "string", format: "date", pattern: "^[0-9]{4}-[0-9]{2}-[0-9]{2}$" }),
        to: Object.freeze({ type: "string", format: "date", pattern: "^[0-9]{4}-[0-9]{2}-[0-9]{2}$" })
      }),
      additionalProperties: false
    })
  });
  var PAGE_TOOL_CATALOG = Object.freeze([...CLAIM_TOOL_CATALOG, SEARCH_TOOL]);
  function catalogForContext(catalog, context) {
    if (context?.environment !== "demo") return catalog;
    return Object.freeze(catalog.map((tool) => Object.freeze({
      ...tool,
      description: `${tool.description} ${SYNTHETIC_DEMO_NOTICE} It is not evidence of official medical or financial data provenance.`
    })));
  }
  function isSearchPageUrl(rawUrl, profile) {
    try {
      const url = new URL(rawUrl ?? "");
      return resolveSiteContext(url, profile) !== void 0 && (url.pathname === SEARCH_PAGE_PATH || url.pathname === SEARCH_ENTRY_PATH && url.searchParams.get("contentid") === SEARCH_CONTENT_ID);
    } catch {
      return false;
    }
  }
  function isSearchResultsUrl(rawUrl, profile) {
    try {
      const url = new URL(rawUrl ?? "");
      return resolveSiteContext(url, profile) !== void 0 && url.pathname === SEARCH_RESULTS_PATH;
    } catch {
      return false;
    }
  }
  function isSearchToolUrl(rawUrl, profile) {
    return isSearchPageUrl(rawUrl, profile) || isSearchResultsUrl(rawUrl, profile);
  }
  function pageToolCatalog(rawUrl, profile) {
    const context = rawUrl === void 0 ? void 0 : resolveSiteContext(rawUrl, profile);
    const catalog = isSearchToolUrl(rawUrl, profile) ? PAGE_TOOL_CATALOG : CLAIM_TOOL_CATALOG;
    return catalogForContext(catalog, context);
  }
  function daysInMonth(year, month) {
    if (month === 2) return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28;
    return [4, 6, 9, 11].includes(month) ? 30 : 31;
  }
  function calendarDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    return year >= 1 && month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth(year, month);
  }
  function isValidSearchInput(input) {
    if (!isExactObject(input, ["from", "to"]) || !calendarDate(input.from) || !calendarDate(input.to)) return false;
    const [year, month, day] = input.from.split("-").map(Number);
    const lastDay = Math.min(day, daysInMonth(year + 5, month));
    const [toYear, toMonth, toDay] = input.to.split("-").map(Number);
    return input.from <= input.to && toYear * 1e4 + toMonth * 100 + toDay <= (year + 5) * 1e4 + month * 100 + lastDay;
  }
  function isValidPageToolInput(tool, input) {
    return tool === "search_claims" ? isValidSearchInput(input) : isValidClaimToolInput(tool, input);
  }
  var CLAIM_TOOL_NAMES = new Set(CLAIM_TOOL_CATALOG.map(({ name }) => name));
  function isExactObject(input, keys) {
    if (input === null || typeof input !== "object" || Array.isArray(input)) return false;
    const prototype = Object.getPrototypeOf(input);
    if (prototype !== Object.prototype && prototype !== null) return false;
    const actual = Object.keys(input);
    return actual.length === keys.length && keys.every((key) => actual.includes(key));
  }
  function isValidClaimToolInput(tool, input) {
    if (tool === "list_claims" || tool === "get_open_claims") return isExactObject(input, []);
    if (tool === "get_claim") {
      return isExactObject(input, ["claimId"]) && typeof input.claimId === "string" && input.claimId.length >= 1 && input.claimId.length <= 256;
    }
    return false;
  }

  // src/webmcp/protocol.ts
  var WEBMCP_BRIDGE_PROTOCOL = "oegk-claim-tracker.webmcp";
  var WEBMCP_BRIDGE_VERSION = 1;
  var WEBMCP_REQUEST_TIMEOUT_MS = 1e4;
  var MAX_REQUEST_ID_LENGTH = 128;
  var MAX_FRAME_LENGTH = 5e6;
  function record(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }
  function onlyKeys(value, keys) {
    const actual = Object.keys(value);
    return actual.length === keys.length && keys.every((key) => actual.includes(key));
  }
  function validRequestId(value) {
    return typeof value === "string" && value.length >= 1 && value.length <= MAX_REQUEST_ID_LENGTH;
  }
  function jsonCompatible(value, depth = 0) {
    if (depth > 24) return false;
    if (value === null || typeof value === "string" || typeof value === "boolean") return true;
    if (typeof value === "number") return Number.isFinite(value);
    if (Array.isArray(value)) return value.every((item) => jsonCompatible(item, depth + 1));
    if (!record(value)) return false;
    return Object.entries(value).every(([key, item]) => key !== "__proto__" && jsonCompatible(item, depth + 1));
  }
  function withinFrameLimit(value) {
    try {
      return JSON.stringify(value).length <= MAX_FRAME_LENGTH;
    } catch {
      return false;
    }
  }
  function isToolResult(value) {
    if (!record(value) || typeof value.ok !== "boolean") return false;
    if (value.ok) {
      return onlyKeys(value, ["ok", "data"]) && jsonCompatible(value.data) && withinFrameLimit(value);
    }
    if (!onlyKeys(value, ["ok", "error"]) || !record(value.error) || !onlyKeys(value.error, ["code", "message"])) return false;
    return (/* @__PURE__ */ new Set(["INVALID_INPUT", "NOT_FOUND", "PAGE_NOT_READY", "EXTRACTION_FAILED", "INTERNAL_ERROR", "UNSUPPORTED_PAGE", "FORM_UNAVAILABLE", "SEARCH_IN_PROGRESS"])).has(
      String(value.error.code)
    ) && typeof value.error.message === "string" && value.error.message.length <= 256 && withinFrameLimit(value);
  }
  function parseBridgeResponse(value) {
    if (!record(value) || !onlyKeys(value, ["protocol", "version", "direction", "requestId", "result"])) {
      return void 0;
    }
    if (value.protocol !== WEBMCP_BRIDGE_PROTOCOL || value.version !== WEBMCP_BRIDGE_VERSION || value.direction !== "response" || !validRequestId(value.requestId) || !isToolResult(value.result) || !withinFrameLimit(value)) return void 0;
    return value;
  }
  function createBridgeRequest(requestId, tool, input) {
    return {
      protocol: WEBMCP_BRIDGE_PROTOCOL,
      version: WEBMCP_BRIDGE_VERSION,
      direction: "request",
      requestId,
      tool,
      input
    };
  }

  // src/webmcp/page-client.ts
  function createPageBridgeClient(pageWindow, timeoutMs = WEBMCP_REQUEST_TIMEOUT_MS, createId = () => crypto.randomUUID()) {
    const pending = /* @__PURE__ */ new Map();
    let disposed = false;
    const cleanup = (requestId) => {
      const request = pending.get(requestId);
      if (!request) return void 0;
      pending.delete(requestId);
      pageWindow.clearTimeout(request.timeout);
      if (request.signal && request.abort) request.signal.removeEventListener("abort", request.abort);
      return request;
    };
    const onMessage = (event) => {
      if (event.source !== pageWindow || event.origin !== pageWindow.location.origin) return;
      const response = parseBridgeResponse(event.data);
      if (!response) return;
      cleanup(response.requestId)?.resolve(response.result);
    };
    pageWindow.addEventListener("message", onMessage);
    return {
      execute(tool, input, options) {
        if (disposed) return Promise.reject(new DOMException("Bridge disposed.", "AbortError"));
        if (options?.signal?.aborted) {
          return Promise.reject(new DOMException("Operation aborted.", "AbortError"));
        }
        let requestId = createId();
        for (let attempt = 0; pending.has(requestId) && attempt < 4; attempt += 1) requestId = createId();
        if (!requestId || requestId.length > 128 || pending.has(requestId)) {
          return Promise.reject(new Error("Unable to create a WebMCP request ID."));
        }
        return new Promise((resolve, reject) => {
          const timeout = pageWindow.setTimeout(() => {
            cleanup(requestId)?.reject(new Error("WebMCP bridge timed out."));
          }, timeoutMs);
          const request = { resolve, reject, timeout };
          if (options?.signal) {
            const signal = options.signal;
            request.signal = signal;
            request.abort = () => {
              cleanup(requestId)?.reject(new DOMException("Operation aborted.", "AbortError"));
            };
            signal.addEventListener("abort", request.abort, { once: true });
          }
          pending.set(requestId, request);
          pageWindow.postMessage(createBridgeRequest(requestId, tool, input), pageWindow.location.origin);
        });
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        pageWindow.removeEventListener("message", onMessage);
        for (const requestId of [...pending.keys()]) {
          cleanup(requestId)?.reject(new DOMException("Bridge disposed.", "AbortError"));
        }
      }
    };
  }

  // src/webmcp/registrar.ts
  var registrations = /* @__PURE__ */ new WeakMap();
  async function registerPageTools(pageDocument, execute, rawUrl) {
    const context = pageDocument.modelContext;
    if (!context || typeof context.registerTool !== "function") {
      return { available: false, reason: "unsupported" };
    }
    const owner = pageDocument;
    const existing = registrations.get(owner);
    if (existing && !existing.signal.aborted) {
      return { available: true, dispose: () => existing.abort() };
    }
    const controller = new AbortController();
    try {
      for (const tool of pageToolCatalog(rawUrl)) {
        const definition = {
          ...tool,
          // The compatibility runtime annotates schemas during validation.
          // Keep the canonical catalog frozen and give each registration a detached copy.
          inputSchema: structuredClone(tool.inputSchema),
          annotations: { readOnlyHint: tool.name !== "search_claims" },
          execute: async (input, options) => {
            if (!isValidPageToolInput(tool.name, input)) {
              return { ok: false, error: { code: "INVALID_INPUT", message: "Invalid input." } };
            }
            return options?.signal ? execute(tool.name, input, { signal: options.signal }) : execute(tool.name, input);
          }
        };
        await context.registerTool(definition, { signal: controller.signal });
      }
      registrations.set(owner, controller);
      return {
        available: true,
        dispose() {
          controller.abort();
          registrations.delete(owner);
        }
      };
    } catch {
      controller.abort();
      registrations.delete(owner);
      return { available: false, reason: "rejected" };
    }
  }

  // src/webmcp/runtime.ts
  async function startWebMcpBridge(pageDocument, pageWindow, loadCompatibilityRuntime2) {
    let runtime = "native";
    if (!pageDocument.modelContext || typeof pageDocument.modelContext.registerTool !== "function") {
      runtime = "polyfill";
      try {
        await loadCompatibilityRuntime2();
      } catch {
        return { available: false, reason: "unsupported" };
      }
    }
    if (!pageDocument.modelContext || typeof pageDocument.modelContext.registerTool !== "function") {
      return { available: false, reason: "unsupported" };
    }
    const client = createPageBridgeClient(pageWindow);
    const registration = await registerPageTools(
      pageDocument,
      (tool, input, options) => client.execute(tool, input, options),
      pageWindow.location.href
    );
    if (!registration.available) {
      client.dispose();
      return registration;
    }
    return {
      available: true,
      runtime,
      dispose() {
        registration.dispose();
        client.dispose();
      }
    };
  }
  function disposeOnFinalPageHide(pageWindow, dispose) {
    const onPageHide = (event) => {
      if (event.persisted) return;
      pageWindow.removeEventListener("pagehide", onPageHide);
      dispose();
    };
    pageWindow.addEventListener("pagehide", onPageHide);
    return () => pageWindow.removeEventListener("pagehide", onPageHide);
  }

  // src/webmcp/scope.ts
  var SUPPORTED_PATHS = /* @__PURE__ */ new Set([
    "/vsInfo/views/KE/einreichungTyp.xhtml",
    "/vsInfo/views/KE/einreichungListe.xhtml",
    "/vsInfo/views/KE/einreichungDetailOA.xhtml",
    "/vsInfo/views/KE/einreichungDetail.xhtml"
  ]);
  function isSupportedMeineSvUrl(rawUrl, profile) {
    if (!rawUrl) return false;
    try {
      const url = new URL(rawUrl);
      return resolveSiteContext(url, profile) !== void 0 && (SUPPORTED_PATHS.has(url.pathname) || isSearchPageUrl(url.toString(), profile));
    } catch {
      return false;
    }
  }

  // src/webmcp/diagnostics.ts
  function writeAttribute(name, value) {
    const root = document.documentElement;
    if (!root) return false;
    root.setAttribute(name, value);
    return true;
  }
  function publishBridgeStatus(name, value) {
    if (writeAttribute(name, value)) return;
    document.addEventListener("DOMContentLoaded", () => writeAttribute(name, value), { once: true });
  }

  // src/webmcp/agent-hint.ts
  var AGENT_HINT_ATTRIBUTE = "data-oegk-webmcp-agent-hint";
  function agentHintText(rawUrl) {
    const names = CLAIM_TOOL_CATALOG.map(({ name }) => name).join(", ");
    const context = rawUrl === void 0 ? void 0 : resolveSiteContext(rawUrl);
    return [
      "WEBMCP AVAILABLE ON THIS PAGE.",
      ...context?.environment === "demo" ? [SYNTHETIC_DEMO_NOTICE, "The current page is a public simulator and does not represent official OEGK records."] : [],
      `Registered read-only OEGK tools: ${names}.`,
      ...isSearchToolUrl(rawUrl) ? ["Also registered: search_claims (not read-only) on the query and results routes; it executes only when the selected Wahlarzt / Wahltherapeut form is present. It returns no claims; submission_requested does not confirm search success or server freshness. Navigation may return null or destroy execution. Never automatically retry an uncertain submission; cancellation cannot undo a dispatched click."] : [],
      "Prefer these structured tools over scraping claim details from the page.",
      "If WebMCP actions are not listed directly, access document.modelContext from the page's MAIN JavaScript world.",
      "Call const tools = await document.modelContext.getTools(), inspect each inputSchema, then call document.modelContext.executeTool(toolObject, JSON.stringify(input)).",
      "Use the tool object returned by getTools(). The three read-only tools extract the current rendered page on every call without refreshing it. No claim history is stored or merged. Check page.completeness and skippedCount; page.visibleRange is displayed controls, not a verified query boundary. IDs expire after content changes or navigation; list again after NOT_FOUND. lastSeen means page read time, not server freshness. Hints alone do not prove callability."
    ].join(" ");
  }
  function installAgentHint(pageDocument, rawUrl = pageDocument.URL) {
    let disposed = false;
    let ownedHint;
    const install = () => {
      if (disposed || pageDocument.querySelector(`[${AGENT_HINT_ATTRIBUTE}]`)) return;
      const hint = pageDocument.createElement("div");
      hint.setAttribute(AGENT_HINT_ATTRIBUTE, "");
      hint.setAttribute("role", "note");
      hint.setAttribute("aria-label", "GovBridge AT WebMCP agent integration metadata");
      hint.style.cssText = [
        "all:initial!important",
        "position:fixed!important",
        "left:-10000px!important",
        "top:auto!important",
        "width:1px!important",
        "height:1px!important",
        "overflow:hidden!important",
        "clip:rect(0,0,0,0)!important",
        "white-space:nowrap!important",
        "pointer-events:none!important"
      ].join(";");
      hint.textContent = agentHintText(rawUrl);
      (pageDocument.body || pageDocument.documentElement)?.append(hint);
      ownedHint = hint;
      pageDocument.documentElement?.setAttribute("data-oegk-webmcp-tools-available", "true");
      pageDocument.documentElement?.setAttribute(
        "data-oegk-webmcp-tool-count",
        String(pageToolCatalog(rawUrl).length)
      );
    };
    if (pageDocument.body || pageDocument.documentElement) install();
    else pageDocument.addEventListener("DOMContentLoaded", install, { once: true });
    return () => {
      disposed = true;
      pageDocument.removeEventListener("DOMContentLoaded", install);
      if (!ownedHint) return;
      ownedHint.remove();
      pageDocument.documentElement?.removeAttribute("data-oegk-webmcp-tools-available");
      pageDocument.documentElement?.removeAttribute("data-oegk-webmcp-tool-count");
    };
  }

  // src/entries/webmcp-main.ts
  async function loadCompatibilityRuntime() {
    const configuredWindow = window;
    configuredWindow.__webMCPPolyfillOptions = { installTestingShim: false };
    try {
      const { initializeWebMCPPolyfill: initializeWebMCPPolyfill2 } = await Promise.resolve().then(() => (init_dist(), dist_exports));
      initializeWebMCPPolyfill2({ installTestingShim: false });
    } finally {
      delete configuredWindow.__webMCPPolyfillOptions;
    }
  }
  if (isSupportedMeineSvUrl(window.location.href)) {
    publishBridgeStatus("data-oegk-webmcp-build", "govbridge-search-v1");
    publishBridgeStatus("data-oegk-webmcp-bridge", "starting");
    void startWebMcpBridge(
      document,
      window,
      loadCompatibilityRuntime
    ).then((result) => {
      if (!result.available) {
        publishBridgeStatus("data-oegk-webmcp-bridge", result.reason);
        return;
      }
      publishBridgeStatus("data-oegk-webmcp-bridge", `ready:${result.runtime}`);
      const removeAgentHint = installAgentHint(document);
      disposeOnFinalPageHide(window, () => {
        removeAgentHint();
        result.dispose();
      });
    }).catch(() => {
      publishBridgeStatus("data-oegk-webmcp-bridge", "failed");
    });
  }
})();
