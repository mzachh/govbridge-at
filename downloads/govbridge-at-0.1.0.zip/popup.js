"use strict";
(() => {
  // src/ui/popup.ts
  function element(document2, tag, text) {
    const node = document2.createElement(tag);
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function renderPopup(root2, model = {}) {
    const document2 = root2.ownerDocument;
    root2.replaceChildren();
    root2.append(
      element(document2, "h1", "GovBridge AT"),
      element(
        document2,
        "p",
        "Live, current-page OEGK tools for WebMCP. Claim data is read only when an agent invokes a tool on a supported Meine-SV page."
      )
    );
    const heading = element(document2, "h2", "Was die Erweiterung bereitstellt");
    heading.id = "capabilities-heading";
    const capabilities = element(document2, "ul");
    capabilities.setAttribute("aria-labelledby", heading.id);
    for (const text of [
      "Drei schreibgesch\xFCtzte Abfragen f\xFCr die aktuell gerenderte Seite",
      "Eine begrenzte search_claims-Aktion f\xFCr das Wahlarzt-/Wahltherapeut-Formular",
      "Keine Speicherung, Kontenaggregation oder PDF-/Dokumentabfrage"
    ]) {
      capabilities.append(element(document2, "li", text));
    }
    const note = element(
      document2,
      "p",
      "Die Ergebnisse sind seitenbezogen und k\xF6nnen unvollst\xE4ndig sein. Tempor\xE4re IDs gelten nur f\xFCr den aktuellen Dokument-Snapshot."
    );
    note.className = "muted";
    const button = element(document2, "button", "WebMCP-Dashboard \xF6ffnen");
    button.type = "button";
    button.addEventListener("click", () => model.onOpenDashboard?.());
    root2.append(heading, capabilities, note, button);
  }

  // src/entries/popup.ts
  var root = document.querySelector("#app");
  if (!root) throw new Error("Popup root missing.");
  renderPopup(root, {
    onOpenDashboard: () => {
      void chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
    }
  });
})();
